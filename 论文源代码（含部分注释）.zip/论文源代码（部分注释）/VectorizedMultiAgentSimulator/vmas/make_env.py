#  Copyright (c) ProrokLab.
#
#  vmas/make_env.py  环境创建入口函数：统一封装VMAS环境的初始化流程

from typing import Optional, Union

from vmas import scenarios
from vmas.simulator.environment import Environment, Wrapper
from vmas.simulator.scenario import BaseScenario
from vmas.simulator.utils import DEVICE_TYPING  # 设备类型：Union[str, int, torch.device]


def make_env(
    scenario: Union[str, BaseScenario],
    num_envs: int,
    device: DEVICE_TYPING = "cpu",
    continuous_actions: bool = True,
    wrapper: Optional[Union[Wrapper, str]] = None,
    max_steps: Optional[int] = None,
    seed: Optional[int] = None,
    dict_spaces: bool = False,
    multidiscrete_actions: bool = False,
    clamp_actions: bool = False,
    grad_enabled: bool = False,
    terminated_truncated: bool = False,
    wrapper_kwargs: Optional[dict] = None,
    **kwargs,
):
    """创建VMAS环境（核心入口函数）
    统一封装场景加载、环境初始化、包装器适配的全流程，支持矢量仿真（批量环境）、离散/连续动作、多框架适配（Gym/RLLib等）

    Args:
        scenario: 场景指定方式
            - 字符串：vmas/scenarios 文件夹下的场景文件名（如"waterfall"）
            - BaseScenario实例：自定义场景类的实例
        num_envs: 矢量仿真的并行环境数量（批量大小）
            VMAS基于PyTorch实现矢量仿真，该参数决定环境的batch_size，所有张量操作均为批量处理
        device: 仿真计算设备（cpu/cuda/xpu等），VMAS创建的所有张量都会放在该设备上，默认"cpu"
        continuous_actions: 是否使用连续动作空间，默认True；若为False则使用离散动作空间
            离散动作的数量/维度由具体场景决定
        wrapper: 环境包装器（适配不同强化学习框架）
            支持字符串或Wrapper枚举值，可选：
            - "rllib"：适配Ray RLLib框架
            - "gym"：适配OpenAI Gym框架
            - "gymnasium"：适配Gymnasium框架
            - "gymnasium_vec"：适配Gymnasium矢量环境
            默认None（不使用包装器，返回原生VMAS环境）
        max_steps: 任务最大步数（回合长度），默认None（无限回合）
            即使场景未终止，达到max_steps也会强制结束当前回合
        seed: 环境随机种子，默认None（不设置种子）
        dict_spaces: 观测/奖励/信息是否使用字典格式，默认False
            - False：返回元组（长度=智能体数量）
            - True：返回字典（键=智能体名称，值=对应张量）
        multidiscrete_actions: 离散动作空间类型，仅当continuous_actions=False时生效，默认False
            - False：动作空间为Discrete（笛卡尔积后的单离散空间）
            - True：动作空间为MultiDiscrete（多维度离散空间）
        clamp_actions: 连续动作越界时是否裁剪，默认False
            - False：动作越界抛出错误
            - True：将动作裁剪到合法范围（-u_range ~ u_range）
        grad_enabled: 是否启用梯度计算，默认False
            - False：输入动作会调用detach()，阻断梯度传播
            - True：保留动作梯度，可从仿真输出反向传播（适用于策略梯度类算法）
        terminated_truncated: step输出是否区分terminated/truncated，默认False
            - False：仅返回done标志（兼容旧版Gym）
            - True：返回terminated（任务完成）和truncated（步数超限）两个标志（兼容Gymnasium）
        wrapper_kwargs: 传递给包装器的关键字参数，默认空字典
        **kwargs: 传递给BaseScenario场景类的自定义参数（如num_agents、landmark_num等）

    示例：
        >>> from vmas import make_env
        >>> # 创建3个并行的waterfall场景环境，包含2个智能体
        >>> env = make_env(
        ...     "waterfall",  # 场景名（对应vmas/scenarios/waterfall.py）
        ...     num_envs=3,   # 并行环境数量
        ...     num_agents=2, # 传递给场景的自定义参数（智能体数量）
        ... )
        >>> print(env.reset())  # 重置环境并打印初始观测
    """

    # ========== 步骤1：加载场景 ==========
    # 如果传入字符串，加载对应场景文件并实例化场景类
    if isinstance(scenario, str):
        # 自动补充.py后缀（用户可省略）
        if not scenario.endswith(".py"):
            scenario += ".py"
        # 从vmas/scenarios文件夹加载场景，创建场景实例
        scenario = scenarios.load(scenario).Scenario()

    # ========== 步骤2：初始化原生VMAS环境 ==========
    env = Environment(
        scenario=scenario,          # 场景实例
        num_envs=num_envs,          # 并行环境数量
        device=device,              # 计算设备
        continuous_actions=continuous_actions,  # 连续/离散动作
        max_steps=max_steps,        # 最大步数
        seed=seed,                  # 随机种子
        dict_spaces=dict_spaces,    # 字典/元组格式的空间
        multidiscrete_actions=multidiscrete_actions,  # 多离散动作空间
        clamp_actions=clamp_actions,  # 动作越界裁剪
        grad_enabled=grad_enabled,  # 梯度启用
        terminated_truncated=terminated_truncated,  # 区分terminated/truncated
        **kwargs,                   # 传递给场景的自定义参数
    )

    # ========== 步骤3：适配环境包装器 ==========
    # 如果包装器是字符串，转换为Wrapper枚举类型（大写匹配）
    if wrapper is not None and isinstance(wrapper, str):
        wrapper = Wrapper[wrapper.upper()]

    # 包装器参数默认空字典
    if wrapper_kwargs is None:
        wrapper_kwargs = {}

    # ========== 步骤4：返回最终环境 ==========
    # 有包装器则返回包装后的环境，否则返回原生环境
    return wrapper.get_env(env, **wrapper_kwargs) if wrapper is not None else env