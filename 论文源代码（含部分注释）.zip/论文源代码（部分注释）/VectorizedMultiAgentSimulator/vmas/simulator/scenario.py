#  Copyright (c) ProrokLab.
#
#  vmas/simulator/scenario.py  场景基类：所有自定义场景必须继承此类并实现核心抽象方法
import typing
from abc import ABC, abstractmethod
from typing import List, Optional

import torch
from torch import Tensor

from vmas.simulator.core import Agent, World
from vmas.simulator.utils import (
    AGENT_INFO_TYPE,      # 智能体信息类型：Dict[str, Tensor]
    AGENT_OBS_TYPE,       # 智能体观测类型：Union[Tensor, Dict[str, Tensor]]
    AGENT_REWARD_TYPE,    # 智能体奖励类型：Tensor
    INITIAL_VIEWER_SIZE,  # 渲染窗口初始尺寸
    VIEWER_DEFAULT_ZOOM,  # 渲染相机默认缩放比例
)

# 仅在类型检查时导入（避免循环导入）
if typing.TYPE_CHECKING:
    from vmas.simulator.rendering import Geom


class BaseScenario(ABC):
    """场景基类（抽象类）
    所有自定义场景都必须继承此类，并实现以下**强制方法**：
    - make_world: 创建仿真世界，初始化智能体、地标等实体
    - reset_world_at: 重置指定环境索引的世界状态（支持批量重置）
    - observation: 为指定智能体生成观测数据
    - reward: 为指定智能体计算奖励

    以下方法为**可选实现**：
    - info: 生成智能体的额外信息字典
    - extra_render: 自定义额外渲染元素（如连线、标记等）
    - process_action: 仿真步前处理智能体动作
    - pre_step: 仿真步前的自定义计算
    - post_step: 仿真步后的自定义计算
    """

    def __init__(self):
        """初始化场景（请勿重写此方法）"""
        self._world = None  # 关联的仿真世界对象（由 make_world 初始化）
        self.viewer_size = INITIAL_VIEWER_SIZE
        """渲染窗口尺寸：可在 make_world 中修改"""
        self.viewer_zoom = VIEWER_DEFAULT_ZOOM
        """渲染相机缩放比例：值越小缩放越大，可在 make_world 中修改"""
        self.render_origin = (0.0, 0.0)
        """渲染相机原点（当未指定聚焦智能体时）：可在 make_world 中修改"""
        self.plot_grid = False
        """是否在渲染背景中绘制网格：可在 make_world 中修改"""
        self.grid_spacing = 0.1
        """网格线间距（仅当 plot_grid=True 时生效）：可在 make_world 中修改"""
        self.visualize_semidims = True
        """是否显示环境边界（仅当世界有尺寸限制时）：可在 make_world 中修改"""

    @property
    def world(self):
        """关联的仿真世界对象（只读属性）
        必须先在 make_world 中初始化 self._world，否则会抛出断言错误
        """
        assert (
            self._world is not None
        ), "必须先在 make_world 方法中设置 self._world"
        return self._world

    def to(self, device: torch.device):
        """将场景所有张量数据迁移到指定设备（CPU/GPU）
        Args:
            device: 目标计算设备（torch.device 对象）
        """
        # 遍历场景所有属性，将张量迁移到目标设备
        for attr, value in self.__dict__.items():
            if isinstance(value, Tensor):
                self.__dict__[attr] = value.to(device)
        # 迁移世界对象的所有数据
        self.world.to(device)

    def env_make_world(self, batch_dim: int, device: torch.device, **kwargs) -> World:
        """环境内部调用的世界创建方法（请勿重写）
        封装 make_world 方法，自动将创建的世界赋值给 self._world
        Args:
            batch_dim: 批量环境数量（矢量仿真的并行环境数）
            device: 计算设备
            **kwargs: 自定义场景参数
        Returns:
            创建的仿真世界对象
        """
        self._world = self.make_world(batch_dim, device, **kwargs)
        return self._world

    def env_reset_world_at(self, env_index: typing.Optional[int]):
        """环境内部调用的世界重置方法（请勿重写）
        先重置世界基础状态，再调用自定义的 reset_world_at 方法
        Args:
            env_index: 要重置的环境索引（None 表示重置所有批量环境）
        """
        self.world.reset(env_index)  # 重置世界所有实体的基础状态（位置/速度等归零）
        self.reset_world_at(env_index)  # 调用自定义的重置逻辑

    def env_process_action(self, agent: Agent):
        """环境内部调用的动作处理方法（请勿重写）
        执行智能体动作回调 → 自定义动作处理 → 动力学动作校验
        Args:
            agent: 要处理动作的智能体
        """
        # 如果智能体有预设动作脚本，执行回调
        if agent.action_script is not None:
            agent.action_callback(self.world)
        # 执行自定义动作处理逻辑（子类可重写）
        self.process_action(agent)
        # 动力学模块校验并处理动作（如速度限制、动作维度检查）
        agent.dynamics.check_and_process_action()

    @abstractmethod
    def make_world(self, batch_dim: int, device: torch.device, **kwargs) -> World:
        """【强制实现】创建仿真世界（核心方法）
        需在此方法中：
        1. 初始化 World 对象（设置批量大小、设备、物理参数等）
        2. 创建并添加智能体（Agent）、地标（Landmark）等实体
        3. 配置场景渲染参数（如 viewer_size、plot_grid 等）

        Args:
            batch_dim: 批量环境数量（矢量仿真，支持并行运行多个环境）
            device: 计算设备（cpu/cuda）
            **kwargs: 自定义场景参数（如智能体数量、地标数量等）

        Returns:
            创建完成的 World 对象（会自动赋值给 self._world）

        示例：
            >>> from vmas.simulator.core import Agent, World, Landmark, Sphere, Box
            >>> from vmas.simulator.scenario import BaseScenario
            >>> from vmas.simulator.utils import Color
            >>> class Scenario(BaseScenario):
            >>>     def make_world(self, batch_dim: int, device: torch.device, **kwargs):
            ...         # 解析自定义参数（创建环境时传入）
            ...         n_agents = kwargs.get("n_agents", 5)
            ...
            ...         # 创建世界：设置批量大小、设备、物理参数
            ...         world = World(batch_dim, device, dt=0.1, drag=0.25, dim_c=0)
            ...         # 添加智能体
            ...         for i in range(n_agents):
            ...             agent = Agent(
            ...                 name=f"agent {i}",          # 智能体名称
            ...                 collide=True,              # 是否可碰撞
            ...                 mass=1.0,                  # 质量
            ...                 shape=Sphere(radius=0.04), # 球形外观
            ...                 max_speed=None,            # 最大速度（None 无限制）
            ...                 color=Color.BLUE,          # 颜色
            ...                 u_range=1.0,               # 动作范围（-1~1）
            ...             )
            ...             world.add_agent(agent)
            ...         # 添加地标
            ...         for i in range(5):
            ...             landmark = Landmark(
            ...                 name=f"landmark {i}",      # 地标名称
            ...                 collide=True,              # 是否可碰撞
            ...                 movable=False,            # 是否可移动
            ...                 shape=Box(length=0.3,width=0.1), # 长方体外观
            ...                 color=Color.RED,           # 颜色
            ...             )
            ...             world.add_landmark(landmark)
            ...         return world
        """
        raise NotImplementedError("必须实现 make_world 方法")

    @abstractmethod
    def reset_world_at(self, env_index: Optional[int] = None):
        """【强制实现】重置指定索引的世界状态
        调用时机：
        - 环境初始化时
        - 每个 episode 结束时
        核心逻辑：
        - env_index=None：批量重置所有并行环境（矢量操作）
        - env_index=int：仅重置指定索引的环境（单环境操作）
        前置条件：
        调用此方法时，所有实体的状态已被归零（位置/速度/旋转等），需在此方法中重新初始化

        常用方法：
        - entity.set_pos(): 设置实体位置
        - entity.set_vel(): 设置实体速度
        - entity.set_rot(): 设置实体旋转角度
        - entity.set_ang_vel(): 设置实体角速度

        性能优化：
        创建张量时直接指定设备：torch.tensor(..., device=self.world.device)

        Args:
            env_index: 要重置的环境索引（None 表示批量重置所有环境）

        固定位置生成示例：
            >>> from vmas.simulator.scenario import BaseScenario
            >>> import torch
            >>> class Scenario(BaseScenario):
            >>>     def reset_world_at(self, env_index):
            ...        # 为每个智能体设置固定位置
            ...        for i, agent in enumerate(self.world.agents):
            ...            agent.set_pos(
            ...                torch.tensor(
            ...                     [-0.2 + 0.1 * i, 1.0],  # x: -0.2, -0.1, 0.0... y: 1.0
            ...                     dtype=torch.float32,
            ...                     device=self.world.device,
            ...                ),
            ...                 batch_index=env_index,  # 指定要设置的环境索引
            ...            )
            ...        # 为每个地标设置固定位置和旋转
            ...        for i, landmark in enumerate(self.world.landmarks):
            ...            landmark.set_pos(
            ...                torch.tensor(
            ...                     [0.2 if i % 2 else -0.2, 0.6 - 0.3 * i],
            ...                     dtype=torch.float32,
            ...                     device=self.world.device,
            ...                ),
            ...                 batch_index=env_index,
            ...            )
            ...            landmark.set_rot(
            ...                torch.tensor(
            ...                     [torch.pi / 4 if i % 2 else -torch.pi / 4],
            ...                     dtype=torch.float32,
            ...                     device=self.world.device,
            ...                ),
            ...                 batch_index=env_index,
            ...            )

        随机位置生成示例：
            >>> from vmas.simulator.scenario import BaseScenario
            >>> from vmas.simulator.utils import ScenarioUtils
            >>> class Scenario(BaseScenario):
            >>>     def reset_world_at(self, env_index):
            >>>         # 随机生成智能体和地标位置（避免重叠）
            >>>         ScenarioUtils.spawn_entities_randomly(
            ...             self.world.agents + self.world.landmarks,  # 要生成位置的实体列表
            ...             self.world,                               # 仿真世界
            ...             env_index,                                # 环境索引
            ...             min_dist_between_entities=0.02,           # 实体间最小间距
            ...             x_bounds=(-1.0,1.0),                      # X轴范围
            ...             y_bounds=(-1.0,1.0),                      # Y轴范围
            ...         )
        """
        raise NotImplementedError("必须实现 reset_world_at 方法")

    @abstractmethod
    def observation(self, agent: Agent) -> AGENT_OBS_TYPE:
        """【强制实现】为指定智能体生成观测数据（矢量操作）
        观测数据需包含智能体决策所需的所有信息，支持两种格式：
        1. 张量格式：shape=(batch_dim, obs_dim)
        2. 字典格式：Dict[str, Tensor]，每个值的 shape=(batch_dim, obs_dim)

        性能优化：
        创建张量时直接指定设备：torch.tensor(..., device=self.world.device)

        Args:
            agent: 要生成观测的智能体

        Returns:
            智能体的观测数据（张量或字典）

        张量观测示例：
            >>> from vmas.simulator.scenario import BaseScenario
            >>> import torch
            >>> class Scenario(BaseScenario):
            >>>     def observation(self, agent):
            ...         # 观测包含：自身位置 + 自身速度 + 所有地标相对位置
            ...         landmark_rel_poses = []
            ...         for landmark in self.world.landmarks:
            ...             landmark_rel_poses.append(landmark.state.pos - agent.state.pos)
            ...         return torch.cat([agent.state.pos, agent.state.vel, *landmark_rel_poses], dim=-1)

        字典观测示例：
            >>> from vmas.simulator.scenario import BaseScenario
            >>> class Scenario(BaseScenario):
            >>>     def observation(self, agent):
            ...         # 观测拆分为位置和速度两个键
            ...         return {"pos": agent.state.pos, "vel": agent.state.vel}
        """
        raise NotImplementedError("必须实现 observation 方法")

    @abstractmethod
    def reward(self, agent: Agent) -> AGENT_REWARD_TYPE:
        """【强制实现】为指定智能体计算奖励（矢量操作）
        奖励张量需为每个并行环境提供一个标量奖励值，shape=(batch_dim,)，dtype=torch.float32

        性能优化：
        创建张量时直接指定设备：torch.tensor(..., device=self.world.device)

        Args:
            agent: 要计算奖励的智能体

        Returns:
            奖励张量（shape=(batch_dim,)）

        示例：
            >>> from vmas.simulator.scenario import BaseScenario
            >>> import torch
            >>> class Scenario(BaseScenario):
            >>>     def reward(self, agent):
            ...         # 奖励 = -智能体到第一个地标距离（距离越近奖励越高）
            ...         rew = -torch.linalg.vector_norm(
            ...             agent.state.pos - self.world.landmarks[0].state.pos,
            ...             dim=-1
            ...         )
            ...         return rew
        """
        raise NotImplementedError("必须实现 reward 方法")

    def done(self) -> Tensor:
        """【可选实现】判断每个环境是否结束（矢量操作）
        返回布尔张量，shape=(batch_dim,)，表示每个并行环境是否结束

        注意：
        - 即使此方法返回 False，当达到 max_steps 时环境也会结束
        - 默认返回全 False（无限 episode）

        性能优化：
        创建张量时直接指定设备：torch.tensor(..., device=self.world.device)

        Returns:
            环境结束标志张量（shape=(batch_dim,)）

        示例：
            >>> from vmas.simulator.scenario import BaseScenario
            >>> import torch
            >>> class Scenario(BaseScenario):
            >>>     def done(self):
            ...         # 当所有智能体电量低于阈值时结束
            ...         threshold = 0.1
            ...         return torch.stack([a.battery_level < threshold for a in self.world.agents], dim=-1).all(-1)
        """
        # 默认返回全 False（无限 episode）
        return torch.tensor([False], device=self.world.device).expand(
            self.world.batch_dim
        )

    def info(self, agent: Agent) -> AGENT_INFO_TYPE:
        """【可选实现】为指定智能体生成额外信息字典（矢量操作）
        信息字典的每个键对应一个张量，shape=(batch_dim, info_size)，用于记录调试/分析信息

        性能优化：
        创建张量时直接指定设备：torch.tensor(..., device=self.world.device)

        Args:
            agent: 要生成信息的智能体

        Returns:
            信息字典（默认空字典）
        """
        return {}

    def extra_render(self, env_index: int = 0) -> "List[Geom]":
        """【可选实现】自定义额外渲染元素（如连线、标记、文本等）
        为指定环境索引添加自定义渲染几何图形，需手动设置颜色、位置、旋转等属性

        Args:
            env_index: 要渲染的环境索引（默认0）

        Returns:
            要渲染的几何图形列表

        示例：
            >>> from vmas.simulator.utils import Color
            >>> from vmas.simulator.scenario import BaseScenario
            >>> class Scenario(BaseScenario):
            >>>     def extra_render(self, env_index):
            >>>         from vmas.simulator import rendering
            >>>         # 在两个智能体之间绘制黑色连线
            >>>         color = Color.BLACK.value
            >>>         line = rendering.Line(
            ...            (self.world.agents[0].state.pos[env_index]),  # 起点：智能体0位置
            ...            (self.world.agents[1].state.pos[env_index]),  # 终点：智能体1位置
            ...            width=1,                                     # 线宽
            ...         )
            >>>         xform = rendering.Transform()
            >>>         line.add_attr(xform)
            >>>         line.set_color(*color)
            >>>         return [line]
        """
        return []

    def process_action(self, agent: Agent):
        """【可选实现】仿真步前处理智能体动作
        可在此方法中修改/约束智能体动作（如动作裁剪、坐标转换、控制器处理等）

        Args:
            agent: 要处理动作的智能体

        示例：
            >>> from vmas.simulator.scenario import BaseScenario
            >>> from vmas.simulator.utils import TorchUtils
            >>> class Scenario(BaseScenario):
            >>>     def process_action(self, agent):
            >>>         # 1. 将方形动作空间裁剪为圆形（保持动作范数不超过最大值）
            >>>         agent.action.u = TorchUtils.clamp_with_norm(agent.action.u, agent.u_range)
            >>>         # 2. 使用PID控制器将速度动作转换为推力（速度控制器示例）
            >>>         # (参考：vmas.simulator.controllers.velocity_controller)
            >>>         agent.controller.process_force()
            >>>         return
        """
        return

    def pre_step(self):
        """【可选实现】仿真步前的自定义计算
        用于执行需要在世界步进前完成的操作（如存储历史状态、更新传感器参数等）

        示例：
            >>> from vmas.simulator.scenario import BaseScenario
            >>> class Scenario(BaseScenario):
            >>>     def pre_step(self):
            >>>         # 存储所有智能体的上一时刻状态
            >>>         for agent in self.world.agents:
            >>>             agent.prev_state = agent.state
            >>>         return
        """
        return

    def post_step(self):
        """【可选实现】仿真步后的自定义计算
        用于执行需要在世界步进后完成的操作（如传感器测量、状态校验、奖励塑形等）

        示例：
            >>> from vmas.simulator.scenario import BaseScenario
            >>> class Scenario(BaseScenario):
            >>>     def post_step(self):
            >>>         # 让每个智能体的第一个传感器执行测量并存储历史数据
            >>>         for agent in self.world.agents:
            >>>             measurements = agent.sensors[0].measure()  # 传感器测量
            >>>             agent.sensor_history.append(measurements)  # 存储测量结果
            >>>         return
        """
        return