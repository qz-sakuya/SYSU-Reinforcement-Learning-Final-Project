#  Copyright (c) ProrokLab.
#
#  vmas/simulator/core.py  仿真核心模块：定义物理实体、多智能体世界、碰撞检测与物理更新逻辑
from __future__ import annotations

import math
import typing
from abc import ABC, abstractmethod
from typing import Callable, List, Sequence, Tuple, Union

import torch
from torch import Tensor

from vmas.simulator.dynamics.common import Dynamics
from vmas.simulator.dynamics.holonomic import Holonomic
from vmas.simulator.joints import Joint
from vmas.simulator.physics import (
    _get_closest_box_box,      # 计算两个盒子的最近点
    _get_closest_line_box,     # 计算线段与盒子的最近点
    _get_closest_point_box,    # 计算点与盒子的最近点
    _get_closest_point_line,   # 计算点与线段的最近点
    _get_closest_points_line_line,  # 计算两条线段的最近点对
    _get_inner_point_box,      # 计算盒子内部点（处理空心/实心盒子碰撞）
)
from vmas.simulator.sensors import Sensor
from vmas.simulator.utils import (
    ANGULAR_FRICTION,      # 默认角摩擦系数
    COLLISION_FORCE,       # 默认碰撞力系数
    Color,                 # 颜色枚举
    DRAG,                  # 默认拖拽系数
    JOINT_FORCE,           # 默认关节力系数
    LINE_MIN_DIST,         # 线段碰撞最小距离阈值
    LINEAR_FRICTION,       # 默认线摩擦系数
    Observable,            # 可观测对象基类
    override,              # 方法重写装饰器
    TorchUtils,            # PyTorch工具类（旋转、叉乘、力矩计算等）
    TORQUE_CONSTRAINT_FORCE, # 默认扭矩约束系数
    X,                     # X轴索引 (0)
    Y,                     # Y轴索引 (1)
)

if typing.TYPE_CHECKING:
    from vmas.simulator.rendering import Geom  # 渲染几何对象（仅类型检查）


class TorchVectorizedObject(object):
    """矢量对象基类（支持批量环境仿真）
    所有物理实体的基类，封装批量维度(batch_dim)和计算设备(device)，
    支持张量设备迁移和批量索引检查
    """
    def __init__(self, batch_dim: int = None, device: torch.device = None):
        # 批量维度：对应并行仿真的环境数量（num_envs）
        self._batch_dim = batch_dim
        # 计算设备：cpu/cuda等
        self._device = device

    @property
    def batch_dim(self):
        return self._batch_dim

    @batch_dim.setter
    def batch_dim(self, batch_dim: int):
        # 批量维度只能设置一次（确保环境初始化后不修改）
        assert self._batch_dim is None, "You can set batch dim only once"
        self._batch_dim = batch_dim

    @property
    def device(self):
        return self._device

    @device.setter
    def device(self, device: torch.device):
        self._device = device

    def _check_batch_index(self, batch_index: int):
        """检查批量索引是否合法（防止越界访问）"""
        if batch_index is not None:
            assert (
                0 <= batch_index < self.batch_dim
            ), f"Index must be between 0 and {self.batch_dim}, got {batch_index}"

    def to(self, device: torch.device):
        """将对象内所有张量迁移到指定设备"""
        self.device = device
        for attr, value in self.__dict__.items():
            if isinstance(value, Tensor):
                self.__dict__[attr] = value.to(device)


class Shape(ABC):
    """几何形状抽象基类
    定义所有形状必须实现的物理属性方法：转动惯量、锚点偏移、几何渲染、外接圆半径
    """
    @abstractmethod
    def moment_of_inertia(self, mass: float):
        """计算转动惯量（依赖质量）"""
        raise NotImplementedError

    @abstractmethod
    def get_delta_from_anchor(self, anchor: Tuple[float, float]) -> Tuple[float, float]:
        """计算从锚点到形状上某点的偏移量"""
        raise NotImplementedError

    @abstractmethod
    def get_geometry(self):
        """获取用于渲染的几何对象"""
        raise NotImplementedError

    @abstractmethod
    def circumscribed_radius(self):
        """计算外接圆半径（用于快速碰撞检测）"""
        raise NotImplementedError


class Box(Shape):
    """矩形形状类
    属性：length(长度/X轴), width(宽度/Y轴), hollow(是否空心)
    """
    def __init__(self, length: float = 0.3, width: float = 0.1, hollow: bool = False):
        super().__init__()
        assert length > 0, f"Length must be > 0, got {length}"
        assert width > 0, f"Width must be > 0, got {length}"
        self._length = length  # X轴长度
        self._width = width    # Y轴宽度
        self.hollow = hollow   # 是否空心（空心盒子碰撞逻辑不同）

    @property
    def length(self):
        return self._length

    @property
    def width(self):
        return self._width

    def get_delta_from_anchor(self, anchor: Tuple[float, float]) -> Tuple[float, float]:
        """锚点偏移计算：锚点坐标 * 半长/半宽"""
        return anchor[X] * self.length / 2, anchor[Y] * self.width / 2

    def moment_of_inertia(self, mass: float):
        """矩形转动惯量公式：I = (1/12) * m * (l² + w²)"""
        return (1 / 12) * mass * (self.length**2 + self.width**2)

    def circumscribed_radius(self):
        """外接圆半径：矩形对角线的一半"""
        return math.sqrt((self.length / 2) ** 2 + (self.width / 2) ** 2)

    def get_geometry(self) -> "Geom":
        """创建渲染用的矩形几何对象"""
        from vmas.simulator import rendering

        # 定义矩形四个顶点（中心在原点）
        l, r, t, b = (
            -self.length / 2,
            self.length / 2,
            self.width / 2,
            -self.width / 2,
        )
        return rendering.make_polygon([(l, b), (l, t), (r, t), (r, b)])


class Sphere(Shape):
    """圆形/球形形状类（2D仿真中为圆形）"""
    def __init__(self, radius: float = 0.05):
        super().__init__()
        assert radius > 0, f"Radius must be > 0, got {radius}"
        self._radius = radius  # 半径

    @property
    def radius(self):
        return self._radius

    def get_delta_from_anchor(self, anchor: Tuple[float, float]) -> Tuple[float, float]:
        """锚点偏移计算：限制偏移不超过半径"""
        delta = torch.tensor([anchor[X] * self.radius, anchor[Y] * self.radius]).to(
            torch.float32
        )
        delta_norm = torch.linalg.vector_norm(delta)
        if delta_norm > self.radius:
            delta /= delta_norm * self.radius  # 归一化到半径范围内
        return tuple(delta.tolist())

    def moment_of_inertia(self, mass: float):
        """圆形转动惯量公式：I = (1/2) * m * r²"""
        return (1 / 2) * mass * self.radius**2

    def circumscribed_radius(self):
        """外接圆半径 = 自身半径"""
        return self.radius

    def get_geometry(self) -> "Geom":
        """创建渲染用的圆形几何对象"""
        from vmas.simulator import rendering

        return rendering.make_circle(self.radius)


class Line(Shape):
    """线段形状类（无宽度，仅用于边界/墙等）"""
    def __init__(self, length: float = 0.5):
        super().__init__()
        assert length > 0, f"Length must be > 0, got {length}"
        self._length = length  # 线段长度
        self._width = 2        # 渲染宽度（物理上无宽度）

    @property
    def length(self):
        return self._length

    @property
    def width(self):
        return self._width

    def moment_of_inertia(self, mass: float):
        """线段转动惯量公式：I = (1/12) * m * l²"""
        return (1 / 12) * mass * (self.length**2)

    def circumscribed_radius(self):
        """外接圆半径 = 半长"""
        return self.length / 2

    def get_delta_from_anchor(self, anchor: Tuple[float, float]) -> Tuple[float, float]:
        """锚点偏移：仅X轴有偏移（线段沿X轴）"""
        return anchor[X] * self.length / 2, 0.0

    def get_geometry(self) -> "Geom":
        """创建渲染用的线段几何对象"""
        from vmas.simulator import rendering

        return rendering.Line(
            (-self.length / 2, 0),  # 起点
            (self.length / 2, 0),   # 终点
            width=self.width,       # 渲染宽度
        )


class EntityState(TorchVectorizedObject):
    """实体物理状态类
    封装位置、速度、旋转角、角速度等核心物理状态，
    支持批量张量操作和设备迁移
    """
    def __init__(self):
        super().__init__()
        # 物理位置 (batch_dim, 2)
        self._pos = None
        # 物理速度 (batch_dim, 2)
        self._vel = None
        # 物理旋转角（范围：-π ~ π）(batch_dim, 1)
        self._rot = None
        # 角速度 (batch_dim, 1)
        self._ang_vel = None

    @property
    def pos(self):
        return self._pos

    @pos.setter
    def pos(self, pos: Tensor):
        """设置位置：检查批量维度和形状合法性"""
        assert (
            self._batch_dim is not None and self._device is not None
        ), "First add an entity to the world before setting its state"
        assert (
            pos.shape[0] == self._batch_dim
        ), f"Internal state must match batch dim, got {pos.shape[0]}, expected {self._batch_dim}"
        if self._vel is not None:
            assert (
                pos.shape == self._vel.shape
            ), f"Position shape must match velocity shape, got {pos.shape} expected {self._vel.shape}"

        self._pos = pos.to(self._device)

    @property
    def vel(self):
        return self._vel

    @vel.setter
    def vel(self, vel: Tensor):
        """设置速度：检查批量维度和形状合法性"""
        assert (
            self._batch_dim is not None and self._device is not None
        ), "First add an entity to the world before setting its state"
        assert (
            vel.shape[0] == self._batch_dim
        ), f"Internal state must match batch dim, got {vel.shape[0]}, expected {self._batch_dim}"
        if self._pos is not None:
            assert (
                vel.shape == self._pos.shape
            ), f"Velocity shape must match position shape, got {vel.shape} expected {self._pos.shape}"

        self._vel = vel.to(self._device)

    @property
    def ang_vel(self):
        return self._ang_vel

    @ang_vel.setter
    def ang_vel(self, ang_vel: Tensor):
        """设置角速度：检查批量维度合法性"""
        assert (
            self._batch_dim is not None and self._device is not None
        ), "First add an entity to the world before setting its state"
        assert (
            ang_vel.shape[0] == self._batch_dim
        ), f"Internal state must match batch dim, got {ang_vel.shape[0]}, expected {self._batch_dim}"

        self._ang_vel = ang_vel.to(self._device)

    @property
    def rot(self):
        return self._rot

    @rot.setter
    def rot(self, rot: Tensor):
        """设置旋转角：检查批量维度合法性"""
        assert (
            self._batch_dim is not None and self._device is not None
        ), "First add an entity to the world before setting its state"
        assert (
            rot.shape[0] == self._batch_dim
        ), f"Internal state must match batch dim, got {rot.shape[0]}, expected {self._batch_dim}"

        self._rot = rot.to(self._device)

    def _reset(self, env_index: typing.Optional[int]):
        """重置指定环境索引的状态为0
        Args:
            env_index: 要重置的环境索引（None表示重置所有环境）
        """
        for attr_name in ["pos", "rot", "vel", "ang_vel"]:
            attr = self.__getattribute__(attr_name)
            if attr is not None:
                if env_index is None:
                    self.__setattr__(attr_name, torch.zeros_like(attr))
                else:
                    self.__setattr__(
                        attr_name,
                        TorchUtils.where_from_index(env_index, 0, attr),
                    )

    def zero_grad(self):
        """清空所有状态张量的梯度（防止梯度累积）"""
        for attr_name in ["pos", "rot", "vel", "ang_vel"]:
            attr = self.__getattribute__(attr_name)
            if attr is not None:
                self.__setattr__(attr_name, attr.detach())

    def _spawn(self, dim_c: int, dim_p: int):
        """初始化状态张量（创建全零张量）
        Args:
            dim_c: 通信维度（实体无通信，仅兼容AgentState）
            dim_p: 物理维度（2D仿真中固定为2）
        """
        self.pos = torch.zeros(
            self.batch_dim, dim_p, device=self.device, dtype=torch.float32
        )
        self.vel = torch.zeros(
            self.batch_dim, dim_p, device=self.device, dtype=torch.float32
        )
        self.rot = torch.zeros(
            self.batch_dim, 1, device=self.device, dtype=torch.float32
        )
        self.ang_vel = torch.zeros(
            self.batch_dim, 1, device=self.device, dtype=torch.float32
        )


class AgentState(EntityState):
    """智能体状态类（继承EntityState，增加通信、力、扭矩）"""
    def __init__(
        self,
    ):
        super().__init__()
        # 通信输出 (batch_dim, dim_c)
        self._c = None
        # 智能体动作产生的力 (batch_dim, 2)
        self._force = None
        # 智能体动作产生的扭矩 (batch_dim, 1)
        self._torque = None

    @property
    def c(self):
        return self._c

    @c.setter
    def c(self, c: Tensor):
        """设置通信状态：检查批量维度合法性"""
        assert (
            self._batch_dim is not None and self._device is not None
        ), "First add an entity to the world before setting its state"
        assert (
            c.shape[0] == self._batch_dim
        ), f"Internal state must match batch dim, got {c.shape[0]}, expected {self._batch_dim}"

        self._c = c.to(self._device)

    @property
    def force(self):
        return self._force

    @force.setter
    def force(self, value):
        """设置作用力：检查批量维度合法性"""
        assert (
            self._batch_dim is not None and self._device is not None
        ), "First add an entity to the world before setting its state"
        assert (
            value.shape[0] == self._batch_dim
        ), f"Internal state must match batch dim, got {value.shape[0]}, expected {self._batch_dim}"

        self._force = value.to(self._device)

    @property
    def torque(self):
        return self._torque

    @torque.setter
    def torque(self, value):
        """设置扭矩：检查批量维度合法性"""
        assert (
            self._batch_dim is not None and self._device is not None
        ), "First add an entity to the world before setting its state"
        assert (
            value.shape[0] == self._batch_dim
        ), f"Internal state must match batch dim, got {value.shape[0]}, expected {self._batch_dim}"

        self._torque = value.to(self._device)

    @override(EntityState)
    def _reset(self, env_index: typing.Optional[int]):
        """重置智能体状态（包含通信、力、扭矩）"""
        for attr_name in ["c", "force", "torque"]:
            attr = self.__getattribute__(attr_name)
            if attr is not None:
                if env_index is None:
                    self.__setattr__(attr_name, torch.zeros_like(attr))
                else:
                    self.__setattr__(
                        attr_name,
                        TorchUtils.where_from_index(env_index, 0, attr),
                    )
        super()._reset(env_index)

    @override(EntityState)
    def zero_grad(self):
        """清空智能体状态梯度（包含通信、力、扭矩）"""
        for attr_name in ["c", "force", "torque"]:
            attr = self.__getattribute__(attr_name)
            if attr is not None:
                self.__setattr__(attr_name, attr.detach())
        super().zero_grad()

    @override(EntityState)
    def _spawn(self, dim_c: int, dim_p: int):
        """初始化智能体状态（包含通信、力、扭矩）"""
        if dim_c > 0:
            self.c = torch.zeros(
                self.batch_dim, dim_c, device=self.device, dtype=torch.float32
            )
        self.force = torch.zeros(
            self.batch_dim, dim_p, device=self.device, dtype=torch.float32
        )
        self.torque = torch.zeros(
            self.batch_dim, 1, device=self.device, dtype=torch.float32
        )
        super()._spawn(dim_c, dim_p)


# 智能体动作类
class Action(TorchVectorizedObject):
    """智能体动作类
    封装物理动作(u)和通信动作(c)，以及动作范围、噪声、乘数等参数
    """
    def __init__(
        self,
        u_range: Union[float, Sequence[float]],  # 动作范围（-u_range ~ u_range）
        u_multiplier: Union[float, Sequence[float]],  # 动作乘数（将动作映射为实际力/扭矩）
        u_noise: Union[float, Sequence[float]],  # 动作噪声（物理动作噪声）
        action_size: int,  # 动作维度
    ):
        super().__init__()
        # 物理动作噪声量
        self._u_noise = u_noise
        # 动作控制范围
        self._u_range = u_range
        # 动作乘数（将归一化动作转换为实际物理量）
        self._u_multiplier = u_multiplier
        # 动作维度
        self.action_size = action_size

        # 物理动作 (batch_dim, action_size)
        self._u = None
        # 通信动作 (batch_dim, dim_c)
        self._c = None

        # 张量形式的动作参数（延迟初始化）
        self._u_range_tensor = None
        self._u_multiplier_tensor = None
        self._u_noise_tensor = None

        self._check_action_init()

    def _check_action_init(self):
        """检查动作参数初始化合法性（列表长度需匹配动作维度）"""
        for attr in (self.u_multiplier, self.u_range, self.u_noise):
            if isinstance(attr, List):
                assert len(attr) == self.action_size, (
                    "Action attributes u_... must be either a float or a list of floats"
                    " (one per action) all with same length"
                )

    @property
    def u(self):
        return self._u

    @u.setter
    def u(self, u: Tensor):
        """设置物理动作：检查批量维度合法性"""
        assert (
            self._batch_dim is not None and self._device is not None
        ), "First add an agent to the world before setting its action"
        assert (
            u.shape[0] == self._batch_dim
        ), f"Action must match batch dim, got {u.shape[0]}, expected {self._batch_dim}"

        self._u = u.to(self._device)

    @property
    def c(self):
        return self._c

    @c.setter
    def c(self, c: Tensor):
        """设置通信动作：检查批量维度合法性"""
        assert (
            self._batch_dim is not None and self._device is not None
        ), "First add an agent to the world before setting its action"
        assert (
            c.shape[0] == self._batch_dim
        ), f"Action must match batch dim, got {c.shape[0]}, expected {self._batch_dim}"

        self._c = c.to(self._device)

    @property
    def u_range(self):
        return self._u_range

    @property
    def u_multiplier(self):
        return self._u_multiplier

    @property
    def u_noise(self):
        return self._u_noise

    @property
    def u_range_tensor(self):
        """延迟初始化：转换为张量形式的动作范围"""
        if self._u_range_tensor is None:
            self._u_range_tensor = self._to_tensor(self.u_range)
        return self._u_range_tensor

    @property
    def u_multiplier_tensor(self):
        """延迟初始化：转换为张量形式的动作乘数"""
        if self._u_multiplier_tensor is None:
            self._u_multiplier_tensor = self._to_tensor(self.u_multiplier)
        return self._u_multiplier_tensor

    @property
    def u_noise_tensor(self):
        """延迟初始化：转换为张量形式的动作噪声"""
        if self._u_noise_tensor is None:
            self._u_noise_tensor = self._to_tensor(self.u_noise)
        return self._u_noise_tensor

    def _to_tensor(self, value):
        """将标量/列表转换为张量（适配动作维度）"""
        return torch.tensor(
            value if isinstance(value, Sequence) else [value] * self.action_size,
            device=self.device,
            dtype=torch.float,
        )

    def _reset(self, env_index: typing.Optional[int]):
        """重置动作状态为0"""
        for attr_name in ["u", "c"]:
            attr = self.__getattribute__(attr_name)
            if attr is not None:
                if env_index is None:
                    self.__setattr__(attr_name, torch.zeros_like(attr))
                else:
                    self.__setattr__(
                        attr_name,
                        TorchUtils.where_from_index(env_index, 0, attr),
                    )

    def zero_grad(self):
        """清空动作张量梯度"""
        for attr_name in ["u", "c"]:
            attr = self.__getattribute__(attr_name)
            if attr is not None:
                self.__setattr__(attr_name, attr.detach())


# 物理世界实体基类
class Entity(TorchVectorizedObject, Observable, ABC):
    """物理实体基类
    所有物理对象（智能体、地标）的基类，封装物理属性（质量、形状、可移动性等）
    和状态管理，支持碰撞检测、物理更新、渲染等功能
    """
    def __init__(
        self,
        name: str,                # 实体名称
        movable: bool = False,    # 是否可移动
        rotatable: bool = False,  # 是否可旋转
        collide: bool = True,     # 是否参与碰撞
        density: float = 25.0,    # 密度（暂未使用）
        mass: float = 1.0,        # 质量
        shape: Shape = None,      # 几何形状（默认球形）
        v_range: float = None,    # 速度范围（限制速度绝对值）
        max_speed: float = None,  # 最大速度（限制速度模长）
        color=Color.GRAY,         # 渲染颜色
        is_joint: bool = False,   # 是否为关节实体
        drag: float = None,       # 拖拽系数（优先使用实体自身值，否则用世界默认值）
        linear_friction: float = None,  # 线摩擦系数
        angular_friction: float = None, # 角摩擦系数
        gravity: typing.Union[float, Tensor] = None,  # 重力（优先使用实体自身值）
        collision_filter: Callable[[Entity], bool] = lambda _: True,  # 碰撞过滤函数
    ):
        if shape is None:
            shape = Sphere()  # 默认球形

        TorchVectorizedObject.__init__(self)
        Observable.__init__(self)
        # 名称
        self._name = name
        # 实体是否可移动/被推动
        self._movable = movable
        # 实体是否可旋转
        self._rotatable = rotatable
        # 实体是否参与碰撞
        self._collide = collide
        # 材料密度（暂未使用）
        self._density = density
        # 质量
        self._mass = mass
        # 最大速度（限制速度模长）
        self._max_speed = max_speed
        # 速度范围（限制速度分量绝对值）
        self._v_range = v_range
        # 渲染颜色
        self._color = color
        # 几何形状
        self._shape = shape
        # 是否为关节实体
        self._is_joint = is_joint
        # 碰撞过滤函数（控制与哪些实体碰撞）
        self._collision_filter = collision_filter
        # 物理状态
        self._state = EntityState()
        # 拖拽系数
        self._drag = drag
        # 摩擦系数
        self._linear_friction = linear_friction
        self._angular_friction = angular_friction
        # 重力（转换为张量）
        if isinstance(gravity, Tensor):
            self._gravity = gravity
        else:
            self._gravity = (
                torch.tensor(gravity, device=self.device, dtype=torch.float32)
                if gravity is not None
                else gravity
            )
        # 实体目标（可选，指向另一个Entity）
        self._goal = None
        # 是否渲染该实体（批量张量）
        self._render = None

    @TorchVectorizedObject.batch_dim.setter
    def batch_dim(self, batch_dim: int):
        """设置批量维度：同步更新状态的批量维度"""
        TorchVectorizedObject.batch_dim.fset(self, batch_dim)
        self._state.batch_dim = batch_dim

    @property
    def is_rendering(self):
        """获取渲染状态（延迟初始化）"""
        if self._render is None:
            self.reset_render()
        return self._render

    def reset_render(self):
        """重置渲染状态为True（所有环境都渲染）"""
        self._render = torch.full((self.batch_dim,), True, device=self.device)

    def collides(self, entity: Entity):
        """判断是否与指定实体碰撞（考虑碰撞过滤）"""
        if not self.collide:
            return False
        return self._collision_filter(entity)

    @property
    def is_joint(self):
        return self._is_joint

    @property
    def mass(self):
        return self._mass

    @mass.setter
    def mass(self, mass: float):
        self._mass = mass

    @property
    def moment_of_inertia(self):
        """计算转动惯量（委托给形状类）"""
        return self.shape.moment_of_inertia(self.mass)

    @property
    def state(self):
        return self._state

    @property
    def movable(self):
        return self._movable

    @property
    def collide(self):
        return self._collide

    @property
    def shape(self):
        return self._shape

    @property
    def max_speed(self):
        return self._max_speed

    @property
    def v_range(self):
        return self._v_range

    @property
    def name(self):
        return self._name

    @property
    def rotatable(self):
        return self._rotatable

    @property
    def color(self):
        """获取渲染颜色（处理Color枚举和张量）"""
        if isinstance(self._color, Color):
            return self._color.value
        return self._color

    @color.setter
    def color(self, color):
        self._color = color

    @property
    def goal(self):
        return self._goal

    @property
    def drag(self):
        return self._drag

    @property
    def linear_friction(self):
        return self._linear_friction

    @linear_friction.setter
    def linear_friction(self, value):
        self._linear_friction = value

    @property
    def gravity(self):
        return self._gravity

    @gravity.setter
    def gravity(self, value):
        self._gravity = value

    @property
    def angular_friction(self):
        return self._angular_friction

    @goal.setter
    def goal(self, goal: Entity):
        self._goal = goal

    @property
    def collision_filter(self):
        return self._collision_filter

    @collision_filter.setter
    def collision_filter(self, collision_filter: Callable[[Entity], bool]):
        self._collision_filter = collision_filter

    def _spawn(self, dim_c: int, dim_p: int):
        """初始化实体状态"""
        self.state._spawn(dim_c, dim_p)

    def _reset(self, env_index: int):
        """重置指定环境的实体状态"""
        self.state._reset(env_index)

    def zero_grad(self):
        """清空实体状态梯度"""
        self.state.zero_grad()

    def set_pos(self, pos: Tensor, batch_index: int):
        """设置指定环境的位置"""
        self._set_state_property(EntityState.pos, self.state, pos, batch_index)

    def set_vel(self, vel: Tensor, batch_index: int):
        """设置指定环境的速度"""
        self._set_state_property(EntityState.vel, self.state, vel, batch_index)

    def set_rot(self, rot: Tensor, batch_index: int):
        """设置指定环境的旋转角"""
        self._set_state_property(EntityState.rot, self.state, rot, batch_index)

    def set_ang_vel(self, ang_vel: Tensor, batch_index: int):
        """设置指定环境的角速度"""
        self._set_state_property(EntityState.ang_vel, self.state, ang_vel, batch_index)

    def _set_state_property(
        self, prop, entity: EntityState, new: Tensor, batch_index: int
    ):
        """通用状态设置方法
        Args:
            prop: 状态属性（如pos/vel）
            entity: 状态对象
            new: 新值张量
            batch_index: 环境索引（None表示所有环境）
        """
        assert (
            self.batch_dim is not None
        ), f"Tried to set property of {self.name} without adding it to the world"
        self._check_batch_index(batch_index)
        new = new.to(self.device)
        if batch_index is None:
            if len(new.shape) > 1 and new.shape[0] == self.batch_dim:
                prop.fset(entity, new)
            else:
                prop.fset(entity, new.repeat(self.batch_dim, 1))
        else:
            value = prop.fget(entity)
            value[batch_index] = new
        self.notify_observers()  # 通知观察者状态变化

    @override(TorchVectorizedObject)
    def to(self, device: torch.device):
        """迁移实体到指定设备（包含状态）"""
        super().to(device)
        self.state.to(device)

    def render(self, env_index: int = 0) -> "List[Geom]":
        """渲染指定环境的实体
        Args:
            env_index: 环境索引（默认0）
        Returns:
            渲染几何对象列表
        """
        from vmas.simulator import rendering

        if not self.is_rendering[env_index]:
            return []
        # 创建形状对应的几何对象
        geom = self.shape.get_geometry()
        xform = rendering.Transform()
        geom.add_attr(xform)

        # 设置位置和旋转
        xform.set_translation(*self.state.pos[env_index])
        xform.set_rotation(self.state.rot[env_index])

        # 设置颜色
        color = self.color
        if isinstance(color, torch.Tensor) and len(color.shape) > 1:
            color = color[env_index]
        geom.set_color(*color)

        return [geom]


# 地标实体类（不可移动的环境对象）
class Landmark(Entity):
    """地标实体类
    继承Entity，默认不可移动、不可旋转，用于表示环境中的固定/被动对象
    """
    def __init__(
        self,
        name: str,
        shape: Shape = None,
        movable: bool = False,
        rotatable: bool = False,
        collide: bool = True,
        density: float = 25.0,  # 暂未使用
        mass: float = 1.0,
        v_range: float = None,
        max_speed: float = None,
        color=Color.GRAY,
        is_joint: bool = False,
        drag: float = None,
        linear_friction: float = None,
        angular_friction: float = None,
        gravity: float = None,
        collision_filter: Callable[[Entity], bool] = lambda _: True,
    ):
        super().__init__(
            name,
            movable,
            rotatable,
            collide,
            density,
            mass,
            shape,
            v_range,
            max_speed,
            color,
            is_joint,
            drag,
            linear_friction,
            angular_friction,
            gravity,
            collision_filter,
        )


# 智能体实体类（可控制的主动对象）
class Agent(Entity):
    """智能体实体类
    继承Entity，增加动作控制、传感器、通信、动力学等智能体特有属性
    """
    def __init__(
        self,
        name: str,
        shape: Shape = None,
        movable: bool = True,      # 默认可移动
        rotatable: bool = True,    # 默认可旋转
        collide: bool = True,
        density: float = 25.0,     # 暂未使用
        mass: float = 1.0,
        f_range: float = None,     # 力范围（限制力绝对值）
        max_f: float = None,       # 最大力（限制力模长）
        t_range: float = None,     # 扭矩范围（限制扭矩绝对值）
        max_t: float = None,       # 最大扭矩（限制扭矩模长）
        v_range: float = None,
        max_speed: float = None,
        color=Color.BLUE,          # 默认蓝色
        alpha: float = 0.5,        # 渲染透明度
        obs_range: float = None,   # 观测范围（超出范围不可见）
        obs_noise: float = None,   # 观测噪声
        u_noise: Union[float, Sequence[float]] = 0.0,  # 动作噪声
        u_range: Union[float, Sequence[float]] = 1.0,  # 动作范围
        u_multiplier: Union[float, Sequence[float]] = 1.0,  # 动作乘数
        action_script: Callable[[Agent, World], None] = None,  # 脚本化动作函数
        sensors: List[Sensor] = None,  # 传感器列表
        c_noise: float = 0.0,      # 通信噪声
        silent: bool = True,       # 是否静音（不发送通信）
        adversary: bool = False,   # 是否为对抗性智能体
        drag: float = None,
        linear_friction: float = None,
        angular_friction: float = None,
        gravity: float = None,
        collision_filter: Callable[[Entity], bool] = lambda _: True,
        render_action: bool = False,  # 是否渲染动作力
        dynamics: Dynamics = None,     # 动力学模型（默认完整动力学）
        action_size: int = None,       # 动作维度（默认由动力学决定）
        discrete_action_nvec: List[int] = None,  # 离散动作维度（默认3维）
    ):
        super().__init__(
            name,
            movable,
            rotatable,
            collide,
            density,
            mass,
            shape,
            v_range,
            max_speed,
            color,
            is_joint=False,
            drag=drag,
            linear_friction=linear_friction,
            angular_friction=angular_friction,
            gravity=gravity,
            collision_filter=collision_filter,
        )
        # 检查：观测范围为0时不能有传感器
        if obs_range == 0.0:
            assert sensors is None, f"Blind agent cannot have sensors, got {sensors}"

        # 检查：动作维度与离散动作维度匹配
        if action_size is not None and discrete_action_nvec is not None:
            if action_size != len(discrete_action_nvec):
                raise ValueError(
                    f"action_size {action_size} is inconsistent with discrete_action_nvec {discrete_action_nvec}"
                )
        # 检查：离散动作维度必须大于1
        if discrete_action_nvec is not None:
            if not all(n > 1 for n in discrete_action_nvec):
                raise ValueError(
                    f"All values in discrete_action_nvec must be greater than 1, got {discrete_action_nvec}"
                )

        # 观测范围（超出范围不可见）
        self._obs_range = obs_range
        # 观测噪声（默认0）
        self._obs_noise = obs_noise
        # 力约束
        self._f_range = f_range
        self._max_f = max_f
        # 扭矩约束
        self._t_range = t_range
        self._max_t = max_t
        # 脚本化动作函数
        self._action_script = action_script
        # 传感器列表
        self._sensors = []
        if sensors is not None:
            [self.add_sensor(sensor) for sensor in sensors]
        # 通信噪声（非微分）
        self._c_noise = c_noise
        # 是否静音（不发送通信）
        self._silent = silent
        # 是否渲染动作力
        self._render_action = render_action
        # 是否为对抗性智能体
        self._adversary = adversary
        # 渲染透明度
        self._alpha = alpha

        # 动力学模型（默认完整动力学）
        self.dynamics = dynamics if dynamics is not None else Holonomic()
        # 动作维度确定逻辑
        if action_size is not None:
            self.action_size = action_size
        elif discrete_action_nvec is not None:
            self.action_size = len(discrete_action_nvec)
        else:
            self.action_size = self.dynamics.needed_action_size
        # 离散动作维度（默认3维：不动/减少/增加）
        if discrete_action_nvec is None:
            self.discrete_action_nvec = [3] * self.action_size
        else:
            self.discrete_action_nvec = discrete_action_nvec
        # 绑定智能体到动力学模型
        self.dynamics.agent = self
        # 初始化动作对象
        self._action = Action(
            u_range=u_range,
            u_multiplier=u_multiplier,
            u_noise=u_noise,
            action_size=self.action_size,
        )

        # 智能体状态（替换Entity的默认状态）
        self._state = AgentState()

    def add_sensor(self, sensor: Sensor):
        """添加传感器（绑定智能体）"""
        sensor.agent = self
        self._sensors.append(sensor)

    @Entity.batch_dim.setter
    def batch_dim(self, batch_dim: int):
        """设置批量维度：同步更新动作的批量维度"""
        Entity.batch_dim.fset(self, batch_dim)
        self._action.batch_dim = batch_dim

    @property
    def action_script(self) -> Callable[[Agent, World], None]:
        return self._action_script

    def action_callback(self, world: World):
        """执行脚本化动作并验证合法性"""
        self._action_script(self, world)
        # 检查：静音智能体不能有通信动作
        if self._silent or world.dim_c == 0:
            assert (
                self._action.c is None
            ), f"Agent {self.name} should not communicate but action script communicates"
        # 检查：必须设置物理动作
        assert (
            self._action.u is not None
        ), f"Action script of {self.name} should set u action"
        # 检查：动作维度匹配
        assert (
            self._action.u.shape[1] == self.action_size
        ), f"Scripted action of agent {self.name} has wrong shape"

        # 检查：动作在合法范围内
        assert (
            (self._action.u / self.action.u_multiplier_tensor).abs()
            <= self.action.u_range_tensor
        ).all(), f"Scripted physical action of {self.name} is out of range"

    @property
    def u_range(self):
        return self.action.u_range

    @property
    def obs_noise(self):
        return self._obs_noise if self._obs_noise is not None else 0

    @property
    def action(self) -> Action:
        return self._action

    @property
    def u_multiplier(self):
        return self.action.u_multiplier

    @property
    def max_f(self):
        return self._max_f

    @property
    def f_range(self):
        return self._f_range

    @property
    def max_t(self):
        return self._max_t

    @property
    def t_range(self):
        return self._t_range

    @property
    def silent(self):
        return self._silent

    @property
    def sensors(self) -> List[Sensor]:
        return self._sensors

    @property
    def u_noise(self):
        return self.action.u_noise

    @property
    def c_noise(self):
        return self._c_noise

    @property
    def adversary(self):
        return self._adversary

    @override(Entity)
    def _spawn(self, dim_c: int, dim_p: int):
        """初始化智能体状态（处理通信维度）"""
        if dim_c == 0:
            assert (
                self.silent
            ), f"Agent {self.name} must be silent when world has no communication"
        if self.silent:
            dim_c = 0
        super()._spawn(dim_c, dim_p)

    @override(Entity)
    def _reset(self, env_index: int):
        """重置智能体状态（包含动作和动力学）"""
        self.action._reset(env_index)
        self.dynamics.reset(env_index)
        super()._reset(env_index)

    def zero_grad(self):
        """清空智能体梯度（包含动作和动力学）"""
        self.action.zero_grad()
        self.dynamics.zero_grad()
        super().zero_grad()

    @override(Entity)
    def to(self, device: torch.device):
        """迁移智能体到指定设备（包含动作和传感器）"""
        super().to(device)
        self.action.to(device)
        for sensor in self.sensors:
            sensor.to(device)

    @override(Entity)
    def render(self, env_index: int = 0) -> "List[Geom]":
        """渲染智能体（包含传感器和动作力）"""
        from vmas.simulator import rendering

        geoms = super().render(env_index)
        if len(geoms) == 0:
            return geoms
        # 设置透明度
        for geom in geoms:
            geom.set_color(*self.color, alpha=self._alpha)
        # 渲染传感器
        if self._sensors is not None:
            for sensor in self._sensors:
                geoms += sensor.render(env_index=env_index)
        # 渲染动作力（如果开启）
        if self._render_action and self.state.force is not None:
            velocity = rendering.Line(
                self.state.pos[env_index],
                self.state.pos[env_index]
                + self.state.force[env_index] * 10 * self.shape.circumscribed_radius(),
                width=2,
            )
            velocity.set_color(*self.color)
            geoms.append(velocity)

        return geoms


# 多智能体世界类（核心仿真管理器）
class World(TorchVectorizedObject):
    """多智能体世界类
    管理所有实体（智能体、地标）、关节、物理参数，
    负责物理仿真的核心流程：力计算、碰撞检测、状态积分更新
    """
    def __init__(
        self,
        batch_dim: int,            # 批量环境数量
        device: torch.device,      # 计算设备
        dt: float = 0.1,           # 仿真时间步长
        substeps: int = 1,         # 子步数量（关节仿真需要更大值）
        drag: float = DRAG,        # 默认拖拽系数
        linear_friction: float = LINEAR_FRICTION,  # 默认线摩擦系数
        angular_friction: float = ANGULAR_FRICTION, # 默认角摩擦系数
        x_semidim: float = None,   # X轴半维度（世界边界）
        y_semidim: float = None,   # Y轴半维度（世界边界）
        dim_c: int = 0,            # 通信维度
        collision_force: float = COLLISION_FORCE,  # 碰撞力系数
        joint_force: float = JOINT_FORCE,          # 关节力系数
        torque_constraint_force: float = TORQUE_CONSTRAINT_FORCE,  # 扭矩约束系数
        contact_margin: float = 1e-3,  # 接触容差（软碰撞）
        gravity: Tuple[float, float] = (0.0, 0.0), # 重力加速度
    ):
        assert batch_dim > 0, f"Batch dim must be greater than 0, got {batch_dim}"

        super().__init__(batch_dim, device)
        # 智能体列表（可动态修改）
        self._agents = []
        # 地标列表（可动态修改）
        self._landmarks = []
        # 世界边界（None表示无边界）
        self._x_semidim = x_semidim
        self._y_semidim = y_semidim
        # 物理维度（2D仿真固定为2）
        self._dim_p = 2
        # 通信维度
        self._dim_c = dim_c
        # 仿真时间步长
        self._dt = dt
        # 子步数量（提高仿真稳定性）
        self._substeps = substeps
        # 子步时间步长
        self._sub_dt = self._dt / self._substeps
        # 拖拽系数
        self._drag = drag
        # 重力（转换为张量）
        self._gravity = torch.tensor(gravity, device=self.device, dtype=torch.float32)
        # 摩擦系数
        self._linear_friction = linear_friction
        self._angular_friction = angular_friction
        # 约束响应参数
        self._collision_force = collision_force
        self._joint_force = joint_force
        self._contact_margin = contact_margin
        self._torque_constraint_force = torque_constraint_force
        # 关节字典（键：实体名称对，值：关节约束）
        self._joints = {}
        # 可碰撞形状对（用于快速过滤）
        self._collidable_pairs = [
            {Sphere, Sphere},
            {Sphere, Box},
            {Sphere, Line},
            {Line, Line},
            {Line, Box},
            {Box, Box},
        ]
        # 实体索引映射（用于快速查找）
        self.entity_index_map = {}

    def add_agent(self, agent: Agent):
        """添加智能体到世界（唯一合法方式）"""
        agent.batch_dim = self._batch_dim
        agent.to(self._device)
        agent._spawn(dim_c=self._dim_c, dim_p=self.dim_p)
        self._agents.append(agent)

    def add_landmark(self, landmark: Landmark):
        """添加地标到世界（唯一合法方式）"""
        landmark.batch_dim = self._batch_dim
        landmark.to(self._device)
        landmark._spawn(dim_c=self.dim_c, dim_p=self.dim_p)
        self._landmarks.append(landmark)

    def add_joint(self, joint: Joint):
        """添加关节到世界"""
        assert self._substeps > 1, "For joints, world substeps needs to be more than 1"
        if joint.landmark is not None:
            self.add_landmark(joint.landmark)
        for constraint in joint.joint_constraints:
            self._joints.update(
                {
                    frozenset(
                        {constraint.entity_a.name, constraint.entity_b.name}
                    ): constraint
                }
            )

    def reset(self, env_index: int):
        """重置指定环境的所有实体状态"""
        for e in self.entities:
            e._reset(env_index)

    def zero_grad(self):
        """清空所有实体的梯度"""
        for e in self.entities:
            e.zero_grad()

    @property
    def agents(self) -> List[Agent]:
        return self._agents

    @property
    def landmarks(self) -> List[Landmark]:
        return self._landmarks

    @property
    def x_semidim(self):
        return self._x_semidim

    @property
    def dt(self):
        return self._dt

    @property
    def y_semidim(self):
        return self._y_semidim

    @property
    def dim_p(self):
        return self._dim_p

    @property
    def dim_c(self):
        return self._dim_c

    @property
    def joints(self):
        return self._joints.values()

    # 返回世界中所有实体
    @property
    def entities(self) -> List[Entity]:
        return self._landmarks + self._agents

    # 返回所有可被外部策略控制的智能体
    @property
    def policy_agents(self) -> List[Agent]:
        return [agent for agent in self._agents if agent.action_script is None]

    # 返回所有被脚本控制的智能体
    @property
    def scripted_agents(self) -> List[Agent]:
        return [agent for agent in self._agents if agent.action_script is not None]

    def _cast_ray_to_box(
        self,
        box: Entity,
        ray_origin: Tensor,
        ray_direction: Tensor,
        max_range: float,
    ):
        """
        射线与盒子的碰撞检测（单射线）
        参考：https://tavianator.com/2011/ray_box.html
        Args:
            box: 目标盒子实体
            ray_origin: 射线起点 (batch_dim, 2)
            ray_direction: 射线方向角 (batch_dim,)
            max_range: 最大检测距离
        Returns:
            碰撞距离（无碰撞返回max_range）
        """
        assert ray_origin.ndim == 2 and ray_direction.ndim == 1
        assert ray_origin.shape[0] == ray_direction.shape[0]
        assert isinstance(box.shape, Box)

        # 转换到盒子局部坐标系
        pos_origin = ray_origin - box.state.pos
        pos_aabb = TorchUtils.rotate_vector(pos_origin, -box.state.rot)
        # 计算世界坐标系下的射线方向
        ray_dir_world = torch.stack(
            [torch.cos(ray_direction), torch.sin(ray_direction)], dim=-1
        )
        # 转换到盒子局部坐标系
        ray_dir_aabb = TorchUtils.rotate_vector(ray_dir_world, -box.state.rot)

        # 计算射线与盒子六个面的交点
        tx1 = (-box.shape.length / 2 - pos_aabb[:, X]) / ray_dir_aabb[:, X]
        tx2 = (box.shape.length / 2 - pos_aabb[:, X]) / ray_dir_aabb[:, X]
        tx = torch.stack([tx1, tx2], dim=-1)
        tmin, _ = torch.min(tx, dim=-1)
        tmax, _ = torch.max(tx, dim=-1)

        ty1 = (-box.shape.width / 2 - pos_aabb[:, Y]) / ray_dir_aabb[:, Y]
        ty2 = (box.shape.width / 2 - pos_aabb[:, Y]) / ray_dir_aabb[:, Y]
        ty = torch.stack([ty1, ty2], dim=-1)
        tymin, _ = torch.min(ty, dim=-1)
        tymax, _ = torch.max(ty, dim=-1)
        tmin, _ = torch.max(torch.stack([tmin, tymin], dim=-1), dim=-1)
        tmax, _ = torch.min(torch.stack([tmax, tymax], dim=-1), dim=-1)

        # 计算交点并转换回世界坐标系
        intersect_aabb = tmin.unsqueeze(1) * ray_dir_aabb + pos_aabb
        intersect_world = (
            TorchUtils.rotate_vector(intersect_aabb, box.state.rot) + box.state.pos
        )

        # 判断是否碰撞
        collision = (tmax >= tmin) & (tmin > 0.0)
        dist = torch.linalg.norm(ray_origin - intersect_world, dim=1)
        dist[~collision] = max_range
        return dist

    def _cast_rays_to_box(
        self,
        box_pos,
        box_rot,
        box_length,
        box_width,
        ray_origin: Tensor,
        ray_direction: Tensor,
        max_range: float,
    ):
        """
        射线与多个盒子的批量碰撞检测
        Args:
            box_pos: 盒子位置 (*batch_size, n_boxes, 2)
            box_rot: 盒子旋转角 (*batch_size, n_boxes)
            box_length: 盒子长度 (*batch_size, n_boxes)
            box_width: 盒子宽度 (*batch_size, n_boxes)
            ray_origin: 射线起点 (*batch_size, 2)
            ray_direction: 射线方向角 (*batch_size, n_angles)
            max_range: 最大检测距离
        Returns:
            碰撞距离矩阵 (*batch_size, n_boxes, n_angles)
        """
        batch_size = ray_origin.shape[:-1]
        assert batch_size[0] == self.batch_dim
        assert ray_origin.shape[-1] == 2  # ray_origin is [*batch_size, 2]
        assert (
            ray_direction.shape[:-1] == batch_size
        )  # ray_direction is [*batch_size, n_angles]
        assert box_pos.shape[:-2] == batch_size
        assert box_pos.shape[-1] == 2
        assert box_rot.shape[:-1] == batch_size
        assert box_width.shape[:-1] == batch_size
        assert box_length.shape[:-1] == batch_size

        num_angles = ray_direction.shape[-1]
        n_boxes = box_pos.shape[-2]

        # 扩展维度以支持批量计算
        ray_origin = (
            ray_origin.unsqueeze(-2)
            .unsqueeze(-2)
            .expand(*batch_size, n_boxes, num_angles, 2)
        )
        box_pos_expanded = box_pos.unsqueeze(-2).expand(
            *batch_size, n_boxes, num_angles, 2
        )
        ray_direction = ray_direction.unsqueeze(-2).expand(
            *batch_size, n_boxes, num_angles
        )
        box_rot_expanded = box_rot.unsqueeze(-1).expand(
            *batch_size, n_boxes, num_angles
        )
        box_width_expanded = box_width.unsqueeze(-1).expand(
            *batch_size, n_boxes, num_angles
        )
        box_length_expanded = box_length.unsqueeze(-1).expand(
            *batch_size, n_boxes, num_angles
        )

        # 转换到盒子局部坐标系
        pos_origin = ray_origin - box_pos_expanded
        pos_aabb = TorchUtils.rotate_vector(pos_origin, -box_rot_expanded)

        # 计算射线方向
        ray_dir_world = torch.stack(
            [torch.cos(ray_direction), torch.sin(ray_direction)], dim=-1
        )
        ray_dir_aabb = TorchUtils.rotate_vector(ray_dir_world, -box_rot_expanded)

        # 计算交点
        tx1 = (-box_length_expanded / 2 - pos_aabb[..., X]) / ray_dir_aabb[..., X]
        tx2 = (box_length_expanded / 2 - pos_aabb[..., X]) / ray_dir_aabb[..., X]
        tx = torch.stack([tx1, tx2], dim=-1)
        tmin, _ = torch.min(tx, dim=-1)
        tmax, _ = torch.max(tx, dim=-1)

        ty1 = (-box_width_expanded / 2 - pos_aabb[..., Y]) / ray_dir_aabb[..., Y]
        ty2 = (box_width_expanded / 2 - pos_aabb[..., Y]) / ray_dir_aabb[..., Y]
        ty = torch.stack([ty1, ty2], dim=-1)
        tymin, _ = torch.min(ty, dim=-1)
        tymax, _ = torch.max(ty, dim=-1)
        tmin, _ = torch.max(torch.stack([tmin, tymin], dim=-1), dim=-1)
        tmax, _ = torch.min(torch.stack([tmax, tymax], dim=-1), dim=-1)

        # 计算交点并转换回世界坐标系
        intersect_aabb = tmin.unsqueeze(-1) * ray_dir_aabb + pos_aabb
        intersect_world = (
            TorchUtils.rotate_vector(intersect_aabb, box_rot_expanded)
            + box_pos_expanded
        )

        # 判断碰撞并计算距离
        collision = (tmax >= tmin) & (tmin > 0.0)
        dist = torch.linalg.norm(ray_origin - intersect_world, dim=-1)
        dist[~collision] = max_range
        return dist

    def _cast_ray_to_sphere(
        self,
        sphere: Entity,
        ray_origin: Tensor,
        ray_direction: Tensor,
        max_range: float,
    ):
        """
        射线与球体的碰撞检测（单射线）
        Args:
            sphere: 目标球体实体
            ray_origin: 射线起点 (batch_dim, 2)
            ray_direction: 射线方向角 (batch_dim,)
            max_range: 最大检测距离
        Returns:
            碰撞距离（无碰撞返回max_range）
        """
        # 计算射线方向
        ray_dir_world = torch.stack(
            [torch.cos(ray_direction), torch.sin(ray_direction)], dim=-1
        )
        # 球体位置
        test_point_pos = sphere.state.pos
        # 构建射线线段（用于最近点计算）
        line_rot = ray_direction
        line_length = max_range
        line_pos = ray_origin + ray_dir_world * (line_length / 2)

        # 计算射线到球体中心的最近点
        closest_point = _get_closest_point_line(
            line_pos,
            line_rot.unsqueeze(-1),
            line_length,
            test_point_pos,
            limit_to_line_length=False,
        )

        # 计算最近点到球体中心的距离
        d = test_point_pos - closest_point
        d_norm = torch.linalg.vector_norm(d, dim=1)
        # 判断是否相交（最近距离 < 球体半径）
        ray_intersects = d_norm < sphere.shape.radius
        # 计算交点距离修正
        a = sphere.shape.radius**2 - d_norm**2
        m = torch.sqrt(torch.where(a > 0, a, 1e-8))

        # 计算最终碰撞距离
        u = test_point_pos - ray_origin
        u1 = closest_point - ray_origin

        u_dot_ray = (u * ray_dir_world).sum(-1)
        sphere_is_in_front = u_dot_ray > 0.0
        dist = torch.linalg.vector_norm(u1, dim=1) - m
        dist[~(ray_intersects & sphere_is_in_front)] = max_range

        return dist

    def _cast_rays_to_sphere(
        self,
        sphere_pos,
        sphere_radius,
        ray_origin: Tensor,
        ray_direction: Tensor,
        max_range: float,
    ):
        """
        射线与多个球体的批量碰撞检测
        """
        batch_size = ray_origin.shape[:-1]
        assert batch_size[0] == self.batch_dim
        assert ray_origin.shape[-1] == 2  # ray_origin is [*batch_size, 2]
        assert (
            ray_direction.shape[:-1] == batch_size
        )  # ray_direction is [*batch_size, n_angles]
        assert sphere_pos.shape[:-2] == batch_size
        assert sphere_pos.shape[-1] == 2
        assert sphere_radius.shape[:-1] == batch_size

        num_angles = ray_direction.shape[-1]
        n_spheres = sphere_pos.shape[-2]

        # 扩展维度
        ray_origin = (
            ray_origin.unsqueeze(-2)
            .unsqueeze(-2)
            .expand(*batch_size, n_spheres, num_angles, 2)
        )
        sphere_pos_expanded = sphere_pos.unsqueeze(-2).expand(
            *batch_size, n_spheres, num_angles, 2
        )
        ray_direction = ray_direction.unsqueeze(-2).expand(
            *batch_size, n_spheres, num_angles
        )
        sphere_radius_expanded = sphere_radius.unsqueeze(-1).expand(
            *batch_size, n_spheres, num_angles
        )

        # 计算射线方向
        ray_dir_world = torch.stack(
            [torch.cos(ray_direction), torch.sin(ray_direction)], dim=-1
        )

        line_rot = ray_direction.unsqueeze(-1)
        line_length = max_range

        # 计算射线线段位置
        line_pos = ray_origin + ray_dir_world * (line_length / 2)

        # 计算最近点
        closest_point = _get_closest_point_line(
            line_pos,
            line_rot,
            line_length,
            sphere_pos_expanded,
            limit_to_line_length=False,
        )

        # 计算距离和碰撞
        d = sphere_pos_expanded - closest_point
        d_norm = torch.linalg.vector_norm(d, dim=-1)
        ray_intersects = d_norm < sphere_radius_expanded
        a = sphere_radius_expanded**2 - d_norm**2
        m = torch.sqrt(torch.where(a > 0, a, 1e-8))

        u = sphere_pos_expanded - ray_origin
        u1 = closest_point - ray_origin

        u_dot_ray = (u * ray_dir_world).sum(-1)
        sphere_is_in_front = u_dot_ray > 0.0
        dist = torch.linalg.vector_norm(u1, dim=-1) - m
        dist[~(ray_intersects & sphere_is_in_front)] = max_range

        return dist

    def _cast_ray_to_line(
        self,
        line: Entity,
        ray_origin: Tensor,
        ray_direction: Tensor,
        max_range: float,
    ):
        """
        射线与线段的碰撞检测（单射线）
        参考：https://stackoverflow.com/questions/563198/how-do-you-detect-where-two-line-segments-intersect/565282#565282
        """
        assert ray_origin.ndim == 2 and ray_direction.ndim == 1
        assert ray_origin.shape[0] == ray_direction.shape[0]
        assert isinstance(line.shape, Line)

        # 线段参数
        p = line.state.pos
        r = (
            torch.stack(
                [
                    torch.cos(line.state.rot.squeeze(1)),
                    torch.sin(line.state.rot.squeeze(1)),
                ],
                dim=-1,
            )
            * line.shape.length
        )

        # 射线参数
        q = ray_origin
        s = torch.stack(
            [
                torch.cos(ray_direction),
                torch.sin(ray_direction),
            ],
            dim=-1,
        )

        # 计算叉乘判断是否平行
        rxs = TorchUtils.cross(r, s)
        t = TorchUtils.cross(q - p, s / rxs)
        u = TorchUtils.cross(q - p, r / rxs)
        d = torch.linalg.norm(u * s, dim=-1)

        # 判断是否有效碰撞
        perpendicular = rxs == 0.0
        above_line = t > 0.5
        below_line = t < -0.5
        behind_line = u < 0.0
        d[perpendicular.squeeze(-1)] = max_range
        d[above_line.squeeze(-1)] = max_range
        d[below_line.squeeze(-1)] = max_range
        d[behind_line.squeeze(-1)] = max_range
        return d

    def _cast_rays_to_line(
        self,
        line_pos,
        line_rot,
        line_length,
        ray_origin: Tensor,
        ray_direction: Tensor,
        max_range: float,
    ):
        """
        射线与多个线段的批量碰撞检测
        """
        batch_size = ray_origin.shape[:-1]
        assert batch_size[0] == self.batch_dim
        assert ray_origin.shape[-1] == 2  # ray_origin is [*batch_size, 2]
        assert (
            ray_direction.shape[:-1] == batch_size
        )  # ray_direction is [*batch_size, n_angles]
        assert line_pos.shape[:-2] == batch_size
        assert line_pos.shape[-1] == 2
        assert line_rot.shape[:-1] == batch_size
        assert line_length.shape[:-1] == batch_size

        num_angles = ray_direction.shape[-1]
        n_lines = line_pos.shape[-2]

        # 扩展维度
        ray_origin = (
            ray_origin.unsqueeze(-2)
            .unsqueeze(-2)
            .expand(*batch_size, n_lines, num_angles, 2)
        )
        line_pos_expanded = line_pos.unsqueeze(-2).expand(
            *batch_size, n_lines, num_angles, 2
        )
        ray_direction = ray_direction.unsqueeze(-2).expand(
            *batch_size, n_lines, num_angles
        )
        line_rot_expanded = line_rot.unsqueeze(-1).expand(
            *batch_size, n_lines, num_angles
        )
        line_length_expanded = line_length.unsqueeze(-1).expand(
            *batch_size, n_lines, num_angles
        )

        # 计算线段方向
        r = torch.stack(
            [
                torch.cos(line_rot_expanded),
                torch.sin(line_rot_expanded),
            ],
            dim=-1,
        ) * line_length_expanded.unsqueeze(-1