#  Copyright (c) ProrokLab.
# vmas/scenarios/transport.py  多智能体运输场景：多个智能体协作推动包裹到目标位置

import torch

from vmas import render_interactively  # 交互式渲染工具：用于手动控制智能体测试场景
from vmas.simulator.core import Agent, Box, Landmark, Sphere, World  # 核心仿真组件
from vmas.simulator.heuristic_policy import BaseHeuristicPolicy  # 启发式策略基类
from vmas.simulator.scenario import BaseScenario  # 场景基类
from vmas.simulator.utils import Color, ScenarioUtils  # 工具类：颜色定义、场景辅助函数


class Scenario(BaseScenario):
    """
    运输场景核心类：
    - 多个智能体需要协作将重型包裹推到目标位置
    - 包裹质量远大于智能体，单个智能体难以推动，需要协作
    - 所有智能体共享奖励：基于包裹到目标的距离变化
    - 当所有包裹到达目标位置时，场景结束
    """

    def make_world(self, batch_dim: int, device: torch.device, **kwargs):
        """
        创建仿真世界（初始化场景）
        Args:
            batch_dim: 批量环境数量（矢量仿真的并行环境数）
            device: 计算设备 (cpu/cuda)
            **kwargs: 自定义参数
                - n_agents: 智能体数量（默认4）
                - n_packages: 包裹数量（默认1）
                - package_width/length: 包裹尺寸（默认0.15）
                - package_mass: 包裹质量（默认50，远大于智能体）
        Returns:
            world: 初始化后的仿真世界对象
        """
        # 解析自定义参数，弹出并使用，避免未使用参数警告
        n_agents = kwargs.pop("n_agents", 4)  # 智能体数量，默认4个
        self.n_packages = kwargs.pop("n_packages", 1)  # 包裹数量，默认1个
        self.package_width = kwargs.pop("package_width", 0.15)  # 包裹宽度
        self.package_length = kwargs.pop("package_length", 0.15)  # 包裹长度
        self.package_mass = kwargs.pop("package_mass", 50)  # 包裹质量（智能体默认质量为1）
        ScenarioUtils.check_kwargs_consumed(kwargs)  # 检查是否有未消费的参数

        # 场景核心参数配置
        self.shaping_factor = 100  # 奖励塑形因子：放大距离差，提升奖励信号
        self.world_semidim = 1  # 世界半尺寸：场景范围为 [-1,1]x[-1,1]
        self.agent_radius = 0.03  # 智能体半径（球形）

        # 创建世界对象：设置批量大小、计算设备、场景边界
        world = World(
            batch_dim,
            device,
            # 扩展场景边界，确保智能体/包裹不会超出范围
            x_semidim=self.world_semidim + 2 * self.agent_radius + max(self.package_length, self.package_width),
            y_semidim=self.world_semidim + 2 * self.agent_radius + max(self.package_length, self.package_width),
        )

        # 添加智能体到世界
        for i in range(n_agents):
            agent = Agent(
                name=f"agent_{i}",  # 智能体命名
                shape=Sphere(self.agent_radius),  # 球形外观
                u_multiplier=0.6,  # 动作放大系数：控制智能体的最大推力
            )
            world.add_agent(agent)

        # 添加目标地标（绿色球体，不可碰撞）
        goal = Landmark(
            name="goal",
            collide=False,  # 不可碰撞：智能体/包裹穿过目标不会被阻挡
            shape=Sphere(radius=0.15),  # 目标半径
            color=Color.LIGHT_GREEN,  # 浅绿色
        )
        world.add_landmark(goal)

        # 创建并添加包裹（可移动、可碰撞的长方体）
        self.packages = []  # 包裹列表，用于后续跟踪
        for i in range(self.n_packages):
            package = Landmark(
                name=f"package {i}",
                collide=True,  # 可碰撞：与智能体/其他包裹会发生物理碰撞
                movable=True,  # 可移动：能被智能体推动
                mass=self.package_mass,  # 包裹质量（重型）
                shape=Box(length=self.package_length, width=self.package_width),  # 长方体形状
                color=Color.RED,  # 初始红色（到达目标后变绿）
            )
            package.goal = goal  # 关联包裹的目标位置
            self.packages.append(package)
            world.add_landmark(package)

        return world

    def reset_world_at(self, env_index: int = None):
        """
        重置场景状态（单个/批量环境）
        Args:
            env_index: 要重置的环境索引（None表示重置所有环境）
        """
        # 1. 随机生成智能体位置：确保智能体之间有足够间距
        ScenarioUtils.spawn_entities_randomly(
            self.world.agents,
            self.world,
            env_index,
            min_dist_between_entities=self.agent_radius * 2,  # 最小间距：避免重叠
            x_bounds=(-self.world_semidim, self.world_semidim),  # X轴范围
            y_bounds=(-self.world_semidim, self.world_semidim),  # Y轴范围
        )

        # 收集智能体已占用的位置：避免包裹/目标与智能体重叠
        agent_occupied_positions = torch.stack(
            [agent.state.pos for agent in self.world.agents], dim=1
        )
        if env_index is not None:
            agent_occupied_positions = agent_occupied_positions[env_index].unsqueeze(0)

        # 2. 随机生成目标和包裹位置：避开智能体位置
        goal = self.world.landmarks[0]
        ScenarioUtils.spawn_entities_randomly(
            [goal] + self.packages,  # 要生成位置的实体：目标 + 所有包裹
            self.world,
            env_index,
            # 最小间距：包裹与目标之间的最小距离
            min_dist_between_entities=max(
                package.shape.circumscribed_radius() + goal.shape.radius + 0.01
                for package in self.packages
            ),
            x_bounds=(-self.world_semidim, self.world_semidim),
            y_bounds=(-self.world_semidim, self.world_semidim),
            occupied_positions=agent_occupied_positions,  # 避开智能体位置
        )

        # 3. 初始化包裹状态：是否在目标上、初始距离奖励塑形值
        for package in self.packages:
            # 检查包裹是否初始就与目标重叠
            package.on_goal = self.world.is_overlapping(package, package.goal)

            # 计算初始距离塑形值（用于奖励计算）
            if env_index is None:
                package.global_shaping = (
                        torch.linalg.vector_norm(
                            package.state.pos - package.goal.state.pos, dim=1
                        ) * self.shaping_factor
                )
            else:
                package.global_shaping[env_index] = (
                        torch.linalg.vector_norm(
                            package.state.pos[env_index] - package.goal.state.pos[env_index]
                        ) * self.shaping_factor
                )

    def reward(self, agent: Agent):
        """
        计算奖励（所有智能体共享相同奖励）
        Args:
            agent: 当前请求奖励的智能体
        Returns:
            rew: 批量环境的奖励值 [batch_dim,]
        """
        # 仅在第一个智能体请求时计算奖励（避免重复计算）
        is_first = agent == self.world.agents[0]

        if is_first:
            # 初始化奖励张量
            self.rew = torch.zeros(
                self.world.batch_dim,
                device=self.world.device,
                dtype=torch.float32,
            )

            # 遍历所有包裹计算奖励
            for package in self.packages:
                # 计算包裹到目标的欧氏距离
                package.dist_to_goal = torch.linalg.vector_norm(
                    package.state.pos - package.goal.state.pos, dim=1
                )
                # 更新包裹是否在目标上的状态
                package.on_goal = self.world.is_overlapping(package, package.goal)

                # 更新包裹颜色：未到达目标为红色，到达为绿色
                package.color = torch.tensor(
                    Color.RED.value, device=self.world.device, dtype=torch.float32
                ).repeat(self.world.batch_dim, 1)
                package.color[package.on_goal] = torch.tensor(
                    Color.GREEN.value, device=self.world.device, dtype=torch.float32
                )

                # 计算奖励塑形：仅对未到达目标的包裹计算
                package_shaping = package.dist_to_goal * self.shaping_factor
                self.rew[~package.on_goal] += (
                        package.global_shaping[~package.on_goal] - package_shaping[~package.on_goal]
                )
                # 更新全局塑形值（用于下一时间步）
                package.global_shaping = package_shaping

        # 所有智能体返回相同的奖励
        return self.rew

    def observation(self, agent: Agent):
        """
        构建智能体的观测空间
        Args:
            agent: 当前智能体
        Returns:
            obs: 观测张量 [batch_dim, obs_dim]
        """
        # 收集每个包裹的观测信息
        package_obs = []
        for package in self.packages:
            package_obs.append(package.state.pos - package.goal.state.pos)  # 包裹到目标的相对位置
            package_obs.append(package.state.pos - agent.state.pos)  # 包裹到智能体的相对位置
            package_obs.append(package.state.vel)  # 包裹的速度
            package_obs.append(package.on_goal.unsqueeze(-1))  # 包裹是否在目标上（布尔值转张量）

        # 拼接最终观测：智能体自身状态 + 所有包裹状态
        return torch.cat(
            [
                agent.state.pos,  # 智能体位置 [x,y]
                agent.state.vel,  # 智能体速度 [vx,vy]
                *package_obs,  # 所有包裹的观测信息
            ],
            dim=-1,
        )

    def done(self):
        """
        判断场景是否结束
        Returns:
            done: 批量环境的结束标志 [batch_dim,] (True=所有包裹到达目标)
        """
        return torch.all(
            torch.stack(
                [package.on_goal for package in self.packages], dim=1
            ),
            dim=-1,  # 检查所有包裹是否都到达目标
        )


class HeuristicPolicy(BaseHeuristicPolicy):
    """
    启发式策略：手动设计的规则策略，用于测试场景
    核心逻辑：智能体采用"运球"策略，推动包裹向目标移动
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 样条插值参数
        self.lookahead = 0.0  # 样条插值的前瞻点（沿轨迹的评估点）
        # 起始速度参数
        self.start_vel_dist_from_target_ratio = 0.5  # 起始速度目标点距离比例
        self.start_vel_behind_ratio = 0.5  # 起始速度向后分量比例
        self.start_vel_mag = 1.0  # 起始速度大小（影响整体轨迹速度）
        # 撞击速度参数
        self.hit_vel_mag = 1.0  # 撞击包裹的速度大小
        # 尺寸参数
        self.package_radius = 0.15 / 2  # 包裹等效半径
        self.agent_radius = -0.02  # 智能体半径（负值表示向内偏移，避免碰撞）
        # 减速参数
        self.dribble_slowdown_dist = 0.0  # 运球减速距离（到达该距离开始减速）
        self.speed = 0.95  # 动作缩放系数（避免最大动作）

    def compute_action(self, observation: torch.Tensor, u_range: float) -> torch.Tensor:
        """
        计算智能体动作
        Args:
            observation: 观测张量 [batch_dim, obs_dim]
            u_range: 动作范围（[-u_range, u_range]）
        Returns:
            action: 智能体动作 [batch_dim, 2] (x/y方向推力)
        """
        self.n_env = observation.shape[0]  # 批量环境数
        self.device = observation.device  # 计算设备

        # 解析观测信息
        agent_pos = observation[:, :2]  # 智能体位置 [x,y]
        # agent_vel = observation[:, 2:4]  # 智能体速度（未使用）
        package_pos = observation[:, 6:8] + agent_pos  # 包裹位置（从相对位置转换为绝对位置）
        goal_pos = -observation[:, 4:6] + package_pos  # 目标位置（从相对位置转换为绝对位置）

        # 计算运球控制动作
        control = self.dribble(agent_pos, package_pos, goal_pos)
        # 缩放动作并限制范围
        control *= self.speed * u_range
        return torch.clamp(control, -u_range, u_range)

    def dribble(self, agent_pos, package_pos, goal_pos, agent_vel=None):
        """
        运球策略：计算推动包裹到目标的动作
        Args:
            agent_pos: 智能体位置 [batch_dim, 2]
            package_pos: 包裹位置 [batch_dim, 2]
            goal_pos: 目标位置 [batch_dim, 2]
            agent_vel: 智能体速度（可选）
        Returns:
            control: 控制动作 [batch_dim, 2]
        """
        # 计算包裹到目标的方向和距离
        package_disp = goal_pos - package_pos  # 包裹到目标的位移
        ball_dist = package_disp.norm(dim=-1)  # 包裹到目标的距离
        direction = package_disp / ball_dist[:, None]  # 归一化方向向量

        # 计算撞击点：包裹朝向目标的反方向（智能体需要到达的位置）
        hit_pos = package_pos - direction * (self.package_radius + self.agent_radius)
        # 计算撞击速度：朝向目标的方向
        hit_vel = direction * self.hit_vel_mag

        # 计算起始速度（用于样条插值）
        start_vel = self.get_start_vel(
            hit_pos, hit_vel, agent_pos, self.start_vel_mag * 2
        )

        # 减速逻辑：当包裹接近目标时减速
        slowdown_mask = ball_dist <= self.dribble_slowdown_dist
        hit_vel[slowdown_mask, :] *= (
                ball_dist[slowdown_mask, None] / self.dribble_slowdown_dist
        )

        # 计算最终控制动作
        return self.get_action(
            target_pos=hit_pos,
            target_vel=hit_vel,
            curr_pos=agent_pos,
            curr_vel=agent_vel,
            start_vel=start_vel,
        )

    def hermite(self, p0, p1, p0dot, p1dot, u=0.0, deriv=0):
        """
        埃尔米特样条插值：计算轨迹上的位置/速度
        Args:
            p0: 起始点位置 [batch_dim, 2]
            p1: 目标点位置 [batch_dim, 2]
            p0dot: 起始点速度 [batch_dim, 2]
            p1dot: 目标点速度 [batch_dim, 2]
            u: 插值参数 [0,1]
            deriv: 导数阶数（0=位置，1=速度）
        Returns:
            ans: 插值结果 [batch_dim, 2]
        """
        # 格式化插值参数
        u = u.reshape((-1,))

        # 计算埃尔米特多项式
        U = torch.stack(
            [
                self.nPr(3, deriv) * (u ** max(0, 3 - deriv)),
                self.nPr(2, deriv) * (u ** max(0, 2 - deriv)),
                self.nPr(1, deriv) * (u ** max(0, 1 - deriv)),
                self.nPr(0, deriv) * (u ** 0),
            ],
            dim=1,
        ).float()

        # 埃尔米特矩阵
        A = torch.tensor(
            [
                [2.0, -2.0, 1.0, 1.0],
                [-3.0, 3.0, -2.0, -1.0],
                [0.0, 0.0, 1.0, 0.0],
                [1.0, 0.0, 0.0, 0.0],
            ],
            device=U.device,
        )

        # 位置/速度矩阵
        P = torch.stack([p0, p1, p0dot, p1dot], dim=1)

        # 计算插值结果
        ans = U[:, None, :] @ A[None, :, :] @ P
        ans = ans.squeeze(1)
        return ans

    def nPr(self, n, r):
        """计算排列数 P(n,r) = n!/(n-r)!"""
        if r > n:
            return 0
        ans = 1
        for k in range(n, max(1, n - r), -1):
            ans = ans * k
        return ans

    def get_start_vel(self, pos, vel, start_pos, start_vel_mag):
        """
        计算起始速度：用于样条插值的初始速度
        Args:
            pos: 目标位置 [batch_dim, 2]
            vel: 目标速度 [batch_dim, 2]
            start_pos: 起始位置 [batch_dim, 2]
            start_vel_mag: 速度大小
        Returns:
            start_vel: 起始速度 [batch_dim, 2]
        """
        # 格式化速度大小
        start_vel_mag = torch.as_tensor(start_vel_mag, device=self.device).view(-1)

        # 计算目标方向
        goal_disp = pos - start_pos
        goal_dist = goal_disp.norm(dim=-1)
        vel_mag = vel.norm(dim=-1)

        # 速度方向（避免除零）
        vel_dir = vel.clone()
        vel_dir[vel_mag > 0] /= vel_mag[vel_mag > 0, None]

        # 目标方向
        goal_dir = goal_disp / goal_dist[:, None]

        # 计算法向方向
        vel_dir_normal = torch.stack([-vel_dir[:, 1], vel_dir[:, 0]], dim=1)
        dot_prod = (goal_dir * vel_dir_normal).sum(dim=1)
        vel_dir_normal[dot_prod > 0, :] *= -1

        # 计算目标点（在包裹后方）
        dist_behind_target = self.start_vel_dist_from_target_ratio * goal_dist
        point_dir = -vel_dir * self.start_vel_behind_ratio + vel_dir_normal * (
                1 - self.start_vel_behind_ratio
        )

        # 计算起始速度方向
        target_pos = pos + point_dir * dist_behind_target[:, None]
        target_disp = target_pos - start_pos
        target_dist = target_disp.norm(dim=1)
        start_vel_aug_dir = target_disp
        start_vel_aug_dir[target_dist > 0] /= target_dist[target_dist > 0, None]

        # 计算最终起始速度
        start_vel = start_vel_aug_dir * start_vel_mag[:, None]
        return start_vel

    def get_action(
            self,
            target_pos,
            target_vel=None,
            start_pos=None,
            start_vel=None,
            curr_pos=None,
            curr_vel=None,
    ):
        """
        计算最终控制动作：基于样条插值的位置/速度跟踪
        Args:
            target_pos: 目标位置 [batch_dim, 2]
            target_vel: 目标速度 [batch_dim, 2]
            start_pos: 起始位置 [batch_dim, 2]
            start_vel: 起始速度 [batch_dim, 2]
            curr_pos: 当前位置 [batch_dim, 2]
            curr_vel: 当前速度 [batch_dim, 2]
        Returns:
            control: 控制动作 [batch_dim, 2]
        """
        # 默认参数处理
        if curr_pos is None:
            curr_pos = torch.zeros(target_pos.shape, device=self.device)
        if curr_vel is None:
            curr_vel = torch.zeros(target_pos.shape, device=self.device)
        if start_pos is None:
            start_pos = curr_pos
        if target_vel is None:
            target_vel = torch.zeros(target_pos.shape, device=self.device)
        if start_vel is None:
            start_vel = self.get_start_vel(
                target_pos, target_vel, start_pos, self.start_vel_mag * 2
            )

        # 计算样条插值的前瞻点
        u_start = torch.ones(curr_pos.shape[0], device=self.device) * self.lookahead
        des_curr_pos = self.hermite(
            start_pos, target_pos, start_vel, target_vel, u=u_start, deriv=0
        )
        des_curr_vel = self.hermite(
            start_pos, target_pos, start_vel, target_vel, u=u_start, deriv=1
        )

        # 转换为张量并确保设备一致
        des_curr_pos = torch.as_tensor(des_curr_pos, device=self.device)
        des_curr_vel = torch.as_tensor(des_curr_vel, device=self.device)

        # PD控制：位置误差 + 速度误差
        control = 0.5 * (des_curr_pos - curr_pos) + 0.5 * (des_curr_vel - curr_vel)
        return control


# 交互式渲染入口：运行此脚本时可手动控制智能体
if __name__ == "__main__":
    render_interactively(__file__, control_two_agents=True)