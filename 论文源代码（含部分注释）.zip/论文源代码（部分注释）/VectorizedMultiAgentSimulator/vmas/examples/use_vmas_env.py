#  Copyright (c) ProrokLab.
#
#  examples/use_vmas_env.py 示例脚本

import random
import time

import torch

from vmas import make_env  # 导入VMAS环境创建函数
from vmas.simulator.core import Agent  # 导入智能体核心类
from vmas.simulator.utils import save_video  # 导入视频保存工具


def _get_deterministic_action(agent: Agent, continuous: bool, env):
    """
    为智能体生成确定性动作（非随机）
    :param agent: 要生成动作的智能体实例
    :param continuous: 是否为连续动作空间（True=连续，False=离散）
    :param env: 所属的环境实例
    :return: 生成的确定性动作张量（与环境设备/批次维度匹配）
    """
    if continuous:
        # 连续动作：生成全为 -u_range 的动作（对应"向下/向左"等固定方向）
        # expand保证动作维度匹配环境的批次大小和智能体动作维度
        action = -agent.action.u_range_tensor.expand(env.batch_dim, agent.action_size)
    else:
        # 离散动作：生成固定值为1的动作张量（对应离散动作空间的第1个动作）
        # unsqueeze(-1)增加维度，expand适配批次维度
        action = (
            torch.tensor([1], device=env.device, dtype=torch.long)
            .unsqueeze(-1)
            .expand(env.batch_dim, 1)
        )
    return action.clone()  # 返回动作副本，避免原张量被意外修改


def use_vmas_env(
        render: bool = False,
        save_render: bool = False,
        num_envs: int = 32,
        n_steps: int = 100,
        random_action: bool = False,
        device: str = "cpu",
        scenario_name: str = "waterfall",
        continuous_actions: bool = True,
        visualize_render: bool = True,
        dict_spaces: bool = True,
        **kwargs,
):
    """
    VMAS多智能体环境的核心使用示例函数
    功能：创建向量化多智能体环境，执行指定步数的动作，支持渲染/保存视频，输出运行效率

    参数说明：
        continuous_actions (bool): 智能体动作空间类型（True=连续动作，False=离散动作）
        scenario_name (str): 场景名称（如"waterfall"瀑布场景、"navigation"导航场景等）
        device (str): 计算设备（"cpu"/"cuda"，建议GPU加速大规模向量化环境）
        render (bool): 是否渲染环境画面（可视化智能体行为）
        save_render (bool): 是否保存渲染画面为视频（需先开启render）
        num_envs (int): 向量化环境的数量（并行运行的环境数，VMAS核心优化点）
        n_steps (int): 每个环境要执行的总步数
        random_action (bool): 动作生成方式（True=随机动作，False=确定性固定动作）
        visualize_render (bool, optional): 渲染时是否可视化界面元素（默认True）
        dict_spaces (bool, optional): 观测/奖励/信息的返回格式（True=字典<智能体名:值>，False=列表）
        kwargs (dict, optional): 场景专属参数（如n_agents=智能体数量、max_steps=场景最大步数等）

    返回值：无
    """
    # 断言检查：保存视频必须先开启渲染，否则抛出异常
    assert not (save_render and not render), "要保存视频必须先开启渲染功能"

    # ========== 核心步骤1：创建VMAS向量化环境 ==========
    env = make_env(
        scenario=scenario_name,  # 指定使用的场景
        num_envs=num_envs,  # 并行环境数量（向量化核心）
        device=device,  # 计算设备
        continuous_actions=continuous_actions,  # 动作空间类型
        dict_spaces=dict_spaces,  # 输出格式（字典/列表）
        wrapper=None,  # 环境包装器（如gym wrapper，此处禁用）
        seed=None,  # 随机种子（None=不固定，便于复现可设固定值如42）
        **kwargs,  # 传递场景专属参数（如n_agents=4）
    )

    frame_list = []  # 存储渲染帧，用于后续生成视频/gif
    init_time = time.time()  # 记录环境运行起始时间（用于计算效率）
    step = 0  # 步数计数器

    # ========== 核心步骤2：环境交互循环（执行指定步数） ==========
    for _ in range(n_steps):
        step += 1
        print(f"当前执行步数：{step}")

        # 随机选择动作输入格式（字典/列表），演示VMAS的灵活兼容性
        # 注：无论dict_spaces设为何值，两种动作格式都可正常使用
        dict_actions = random.choice([True, False])

        # 初始化动作容器（字典/列表）
        actions = {} if dict_actions else []
        # 为每个智能体生成动作
        for agent in env.agents:
            if not random_action:
                # 生成确定性动作（固定策略）
                action = _get_deterministic_action(agent, continuous_actions, env)
            else:
                # 生成随机动作（从智能体动作空间随机采样）
                action = env.get_random_action(agent)

            # 将动作添加到容器（匹配所选格式）
            if dict_actions:
                actions.update({agent.name: action})  # 字典格式：{智能体名: 动作张量}
            else:
                actions.append(action)  # 列表格式：[智能体1动作, 智能体2动作, ...]

        # ========== 核心步骤3：环境步进（执行动作，获取反馈） ==========
        # obs: 观测（字典/列表，每个元素是对应智能体的观测张量）
        # rews: 奖励（同上，每个元素是对应智能体的奖励值）
        # dones: 结束标志（是否达到场景终止条件）
        # info: 额外信息（如碰撞、距离等场景专属数据）
        obs, rews, dones, info = env.step(actions)

        # ========== 可选步骤：渲染与视频保存 ==========
        if render:
            # 渲染环境为RGB数组（用于保存视频）
            # mode="rgb_array"：返回像素数组；mode="human"：直接显示窗口
            # agent_index_focus：相机聚焦的智能体索引（None=全局视角）
            frame = env.render(
                mode="rgb_array",
                agent_index_focus=None,
                visualize_when_rgb=visualize_render,
            )
            if save_render:
                frame_list.append(frame)  # 收集帧数据

    # ========== 运行效率统计 ==========
    total_time = time.time() - init_time
    print(
        f"运行耗时：{total_time:.2f}秒 | "
        f"执行步数：{n_steps}步 | "
        f"并行环境数：{num_envs} | "
        f"设备：{device} | "
        f"场景：{scenario_name}"
    )

    # ========== 保存渲染视频 ==========
    if render and save_render:
        # fps=1/env.scenario.world.dt：按场景物理步长设置帧率（保证视频速度与实际一致）
        save_video(scenario_name, frame_list, fps=1 / env.scenario.world.dt)


# ========== 主函数：运行示例 ==========
if __name__ == "__main__":
    use_vmas_env(
        scenario_name="waterfall",  # 使用"waterfall"瀑布场景
        render=True,  # 开启可视化渲染
        save_render=False,  # 不保存视频
        random_action=False,  # 使用确定性动作（非随机）
        continuous_actions=False,  # 离散动作空间
        n_agents=4,  # 场景专属参数：智能体数量为4
    )