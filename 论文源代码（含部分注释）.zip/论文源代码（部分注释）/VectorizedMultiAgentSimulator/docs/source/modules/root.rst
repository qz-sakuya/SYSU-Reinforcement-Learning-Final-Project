vmas
====


.. automodule:: vmas
    :members:
